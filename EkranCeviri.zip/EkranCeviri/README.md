![Ekran Çeviri](docs/cover.png)

# Ekran Çeviri (Android)

CeBo Translator'ın mantığı: ekranı oku -> yazıyı bul -> çevir -> yazının tam üstüne çiz.
Hedef uygulamaya (oyun, video) hiçbir şey kurulmaz; yalnız ekran görüntüsü alınır, üstüne şeffaf katman çizilir.

## Çalıştırma
1. Android Studio'yu aç (Koala 2024.1 ve üstü) -> Open -> bu klasörü seç, Gradle senkronu bitsin.
2. Gerçek bir Android telefonu USB hata ayıklama ile bağla (Android 8+), Run.
3. Uygulamada "Başlat": önce "Diğer uygulamaların üzerinde göster" iznini aç, geri dönüp tekrar bas.
4. İlk seferde çeviri modeli (~30 MB) iner, sonra ekran yakalama iznini onayla.
5. Oyunu / videoyu aç, ekrandaki TR balonuna dokun: yazılar Türkçe olur. Tekrar dokunursan silinir. Balon sürüklenebilir.
6. Durdurmak için bildirimdeki "Durdur".

## Mimari
- MainActivity.kt: izinler + modeli indirme + ekran yakalama izni
- CaptureService.kt: MediaProjection ile ekran karesi, ML Kit ile OCR + çeviri, balon ve katman pencereleri
- OverlayView.kt: çevrilmiş yazıları orijinal yerine, arka plan rengiyle çizer
- OcrTools.kt: çift OCR (normal + kontrastı artırılmış/1.5x büyütülmüş görüntü), kalite puanı, iki sonucu birleştirme
- TextCleaner.kt: OCR hatalarını temizler (| -> I, y0u -> you, satır sonu, boşluk, BÜYÜK HARF -> cümle düzeni)
- Glossary.kt + assets/glossary.txt: oyun sözlüğü; isimler çeviriden korunur, OCR'ın 1 harf bozduğu isimler düzeltilir

## Kullanım
- **Dokun:** ekranı çevir. Tekrar dokun: çeviriyi sil.
- **Uzun bas:** menü → *Alan seç*, *Otomatik çeviriyi aç/kapat*, *Çeviriyi sil*, *Durdur*.
- **Alan seçme:** parmakla bir dikdörtgen çiz; sonra yalnız orası okunur ve çevrilir (daha hızlı, daha isabetli). **Birden fazla alan** eklenebilir (en çok 4): menüde *Alan ekle*; mevcut alanlar sarı çerçeveyle görünür, çakışan alanlar birleşir. Boş dokunuş seçimi iptal eder, *Alanları kaldır* hepsini siler.
- **Bir daha çevirme:** menü → *Bir daha çevirme…*; ekrandaki çevirilerin çevresine kırmızı çerçeve çıkar, çevrilmesini istemediğin yazıya dokun. O yazı kalıcı listeye girer ve her modda atlanır (OCR'ın 1-2 harflik hataları da eşleşir). Liste ana ekranda *Çevrilmeyecek yazılar* bölümünden düzenlenir (silme, elle ekleme).
- **Otomatik çeviri:** ekran değişince (yeni diyalog vb.) kendiliğinden yeniden çevirir. Yazı hâlâ yazılıyorsa (daktilo efekti) bitmesini bekler. Balon turkuaz olur.

## Çeviri motorları (ana ekrandan seçilir)
- **Çevrimdışı (ML Kit):** internetsiz, hızlı, kalite orta.
- **Gemini:** ekrandaki tüm yazı bloğu tek istekte, birbirine bağlam olarak gider; oyun sözlüğündeki isimler çevrilmez. En iyi kalite. Ücretsiz anahtar: aistudio.google.com/apikey
- **DeepL:** sözlük terimleri korunur. Ücretsiz anahtar: deepl.com/pro-api
- Bulut motoru hata verirse (internet yok, anahtar yanlış, kota) kendiliğinden çevrimdışıya düşer.
- Anahtarlar yalnız telefonda (uygulamanın özel alanı) saklanır; bulut seçiliyse ekrandaki yazılar Google/DeepL'e gönderilir.

## Altyazı gibi takip (otomatik mod)
- Çeviri, orijinal yazı ekranda olduğu sürece **yerinde sabit** kalır; her turda yeniden çizilmez, kaymaz, boyu değişmez.
- Aynı yazı tekrar çevrilmez. Yazı hâlâ yazılıyorsa (daktilo efekti) bitmesi beklenir; cümle noktalama ile bittiyse hemen çevrilir.
- Yazı ekrandan gidince çeviri ayarlanan süre sonra kalkar. OCR bir turda yazıyı kaçırırsa çeviri hemen silinmez.
- Bir çeviri, yeni satır gelse bile en az ayarlanan süre ekranda kalır (okumaya vakit). Yeni satır o zamana kadar bekletilir.
- Ayarlar ana ekranda: *Çeviri en az şu kadar ekranda kalsın* (1,5–6 sn) ve *Yazı gidince çeviri şu kadar sonra kalksın* (0,6–3 sn).
- Ekran durağansa OCR çalışmaz (pil tasarrufu); hareketli sahnede her turda çalışır.

## Çevrilmeyen yazılar (Wuthering Waves)
`app/src/main/assets/skip_rules.txt` — her satır bir düzenli ifade. Eşleşen blok hiç çevrilmez:
UID, sürüm numarası, `Lv. 80/90`, yalnız sayı/süre/yüzde (hasar sayıları, geri sayım), `HP 12,000` gibi istatistik satırları, `Astrite 1,250` gibi sayaçlar, FPS/ping, saat/tarih, bağlantılar.
Çevrilen bir şey çevrilmemeliyse oraya bir satır ekle. Karakter/yer isimleri ise `glossary.txt` ile korunur.

## Hız
- Otomatik modda tek OCR geçişi yapılır, tarama aralığı ana ekrandan seçilir (Hızlı 0,5 sn / Normal 0,8 sn / Ekonomik 1,5 sn).
- Gemini/DeepL seçiliyse bulut cevabı gelene kadar çevrimdışı çeviri hemen gösterilir, sonra daha iyisiyle değişir.
- Çeviri değişirken eski çeviri silinip yenisi eklenmez, üst üste geçilir (yanıp sönme yok).

## Diyalog hafızası
Gemini/DeepL seçiliyken son 3 dakikada çevrilen satırlar (en fazla 8) bağlam olarak gönderilir: isimler, hitaplar ve konuşma tonu diyalog boyunca tutarlı kalır. Bağlam satırları tekrar çevrilmez. Yalnız çevrilen metinde geçen sözlük terimleri istemeye eklenir (kısa istem, hızlı cevap).

## İsimlere Türkçe ek (çevrimdışı da çalışır)
`TurkishSuffix.kt`: sözlükteki isimlere gelen hâl ekleri (-e/-a, -i, -in, -de, -den, -le) ismin okunuşuna göre yeniden kurulur: ünlü uyumu (Yinlin'e / Verina'ya / Rover'a), kaynaştırma (Jinhsi'nin, Calcharo'nun), sert ünsüz (Brant'ta), sessiz e (Encore'un). ML Kit yer tutucudan sonra yanlış ek getirirse düzeltilir; Gemini/DeepL çıktısındaki `Ad'ek` biçimleri de aynı kuralla denetlenir. Okunuşu yazılışından farklı isimler `TurkishSuffix.SOUND` listesindedir (Phoebe, Hecate...); yenisi çıkarsa oraya ekle.

## Sözlük kaynağı
`glossary.txt` (yaklaşık 350 terim) herkese açık wiki sayfalarından derlendi: v3.8'e kadar tüm Rezonatörler, Echo adları (1/3/4 maliyet, Nightmare ve Reminiscence dahil), Sonata etkileri, bölgeler ve oyun terimleri. Yeni karakter/echo çıkınca satır eklemen yeter.

## Sözlüğü düzenleme
`app/src/main/assets/glossary.txt` — her satır `İngilizce terim | isteğe bağlı Türkçe karşılık`.
Karşılık boşsa terim aynen kalır. Yeni karakter/yer çıkınca bu dosyaya satır eklemen yeter.

## Çeviri hata toleransı
- Bir blok çevrilemezse 1 kez tekrar denenir, olmazsa atlanır; diğer yazılar yine çizilir.
- 30 sn içinde bitmezse eldeki sonuç gösterilir, balon takılı kalmaz.
- Aynı metin tekrar çevrilmez (önbellek).

## v0.8 — otomatik çeviri düzeltmeleri (CeBo incelemesinden)
- **Yanıp sönme azaldı:** otomatik modda çeviri katmanı artık her turda gizlenmiyor. Yalnız karar bekleyen bir şey varsa, kutuların DIŞINDA ekran değiştiyse (en az 1 sn arayla) ya da en geç 2,2 sn'de bir gizlenip altına bakılır. CeBo Windows'ta kendi penceresini yakalamadan hariç tutabildiği için hiç yanıp sönmez; Android'de buna izin veren genel bir API yok, bu yüzden tamamen sıfırlanamaz, yalnız azaltılır.
- **Kendi çevirisini tekrar okumuyor:** OCR çeviri katmanını okursa (ya da oyun menüsü zaten Türkçeyse) o blok atlanır (ğ ş ı İ gibi harfler, Türkçe sözcükler, ekrandaki çevirilerimize benzerlik). Eskiden Türkçe yazı "İngilizce" sanılıp anlamsız çevrilebiliyordu.
- **Daha az bellek/işlemci:** durağan ekranı kontrol için her turda ~10 MB'lık tam ekran Bitmap kopyalanmıyor; imza doğrudan ekran tamponundan örneklenir. Tam kare yalnız OCR gerçekten gerekince alınır.
- **Gemini:** `gemini-3*` modellerinde düşünme seviyesi "minimal" (çeviri için gecikmeyi azaltır) ve sıcaklık varsayılan bırakıldı (Google, Gemini 3 için varsayılanı öneriyor). Adlara Türkçe ek apostrofla eklenir (Kenway'le). Zaten Türkçe bloklar aynen döner.
- Bulut zaman aşımları kısaldı (bağlantı 6 sn, okuma 15 sn); otomatik modda genel zaman aşımı 15 sn. Çeviri önbelleği 600 kayıtta sıfırlanır.

## v0.9 — otomatik çeviri düzeltmeleri
- **Kendi çevirisini okuma hatası:** katman gizlenince "yeni kare geldi" yetmiyordu; oyun 60 fps çiziyorsa o kare katman kalkmadan önce çizilmiş olabiliyor ve OCR kendi Türkçe çevirimizi okuyordu. Artık yeni kare + en az 80 ms bekleniyor.
- **Eski çeviri kalıyordu:** `3/5` -> `4/5` gibi yalnız sayısı değişen yazılar "aynı yazı" sanılıp eski çeviri tutuluyordu. Sayılar farklıysa artık yeniden çevriliyor.
- **Gemini satır sayısı tutmazsa hepsi çöpe gitmiyordu:** cevap artık `{id, text}` biçiminde; eksik satır yalnız çevrimdışıyla tamamlanıyor, diğerleri Gemini çevirisiyle kalıyor.

## Bilinen sınırlar
- v0.8 değişiklikleri derlenip telefonda denenmedi (burada Android SDK yok); ilk derlemede küçük düzeltme gerekebilir.
- Henüz derlenip telefonda denenmedi; ilk derlemede küçük düzeltmeler gerekebilir.
- Her dokunuşta tek kare çevrilir (CeBo gibi otomatik sürekli çeviri yok).
- Korumalı (FLAG_SECURE) uygulamalar ekran yakalamada boş görünür.
- Çok süslü fontlarda OCR hâlâ hata yapabilir (çift OCR bunu azaltır, sıfırlamaz).
- Çeviri motoru ML Kit (çevrimdışı); uzun/deyimsel cümlelerde kalite sınırlıdır.


## v1.0 — Android otomatik tarama iyileştirmesi
- Otomatik modda her ikinci OCR kararında tam ekran taraması zorunlu: küçük yazı değişiklikleri yalnızca piksel farkı eşiğine takılıp kaçmasın.
- Çeviri katmanı açıkken kaynak ekranı kontrol etme aralığı 2,2 sn'den 1,4 sn'ye; en erken kontrol aralığı 1 sn'den 0,6 sn'ye indirildi.
- Yeni kurulumlarda varsayılan otomatik kontrol aralığı 0,5 sn. Mevcut kullanıcıların seçtiği aralık korunur.
- Not: Bu değişiklikler Android'deki MediaProjection + ML Kit mimarisine yöneliktir. CeBo'nun masaüstü yakalama yöntemi Android'e birebir taşınamaz; Android'in ekran yakalama/overlay kısıtları devam eder.
