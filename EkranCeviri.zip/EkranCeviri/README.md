# Ekran Çeviri (Android)

CeBo Translator'ın mantığı: ekranı oku -> yazıyı bul -> çevir -> yazının tam üstüne çiz.
Hedef uygulamaya (oyun, video) hiçbir şey kurulmaz; yalnız ekran görüntüsü alınır, üstüne şeffaf katman çizilir.

## Çalıştırma
1. Android Studio'yu aç (Koala 2024.1 ve üstü) -> Open -> bu klasörü seç, Gradle senkronu bitsin.
2. Gerçek bir Android telefonu USB hata ayıklama ile bağla (Android 8+), Run.
3. Uygulamada "Başlat": önce "Diğer uygulamaların üzerinde göster" iznini aç, geri dönüp tekrar bas.
4. İlk seferde çeviri modeli (~30 MB) iner, sonra ekran yakalama iznini onayla.
5. Oyunu / videoyu aç, ekrandaki TR balonuna dokun: yazılar Türkçe olur. Tekrar dokunursan silinir. Balon sürüklenebilir.
6. Durdurmak için bildirimdeki "Durdur".

## Mimari
- MainActivity.kt: izinler + modeli indirme + ekran yakalama izni
- CaptureService.kt: MediaProjection ile ekran karesi, ML Kit ile OCR + çeviri, balon ve katman pencereleri
- OverlayView.kt: çevrilmiş yazıları orijinal yerine, arka plan rengiyle çizer

## Bilinen sınırlar
- Henüz derlenip telefonda denenmedi; ilk derlemede küçük düzeltmeler gerekebilir.
- Her dokunuşta tek kare çevrilir (CeBo gibi otomatik sürekli çeviri yok).
- Korumalı (FLAG_SECURE) uygulamalar ekran yakalamada boş görünür.
- Stilize oyun fontlarında OCR hata yapabilir. İsimleri koruma yok.
