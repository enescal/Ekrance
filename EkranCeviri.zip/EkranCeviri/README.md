![Ekran Çeviri](docs/cover.png)

# Ekran Çeviri (Android)

CeBo Translator'ın mantığı: ekranı oku -> yazıyı bul -> çevir -> yazının tam üstüne çiz.
Hedef uygulamaya (oyun, video) hiçbir şey kurulmaz; yalnız ekran görüntüsü alınır, üstüne şeffaf katman çizilir.

## Çalıştırma
1. Android Studio'yu aç (Koala 2024.1 ve üstü) -> Open -> bu klasörü seç, Gradle senkronu bitsin.
2. Gerçek bir Android telefonu USB hata ayıklama ile bağla (Android 8+), Run.
3. Uygulamada "Başlat": önce "Diğer uygulamaların üzerinde göster" iznini aç, geri dönüp tekrar bas.
4. İlk seferde çeviri modeli (~30 MB) iner, sonra ekran yakalama iznini onayla.
5. Oyunu / videoyu aç, ekrandaki TR balonuna dokun: yazılar Türkçe olur. Tekrar dokunursan silinir. Balon sürüklenebilir.
6. Durdurmak için bildirimdeki "Durdur".

## Mimari
- MainActivity.kt: izinler + modeli indirme + ekran yakalama izni
- CaptureService.kt: MediaProjection ile ekran karesi, ML Kit ile OCR + çeviri, balon ve katman pencereleri
- OverlayView.kt: çevrilmiş yazıları orijinal yerine, arka plan rengiyle çizer
- OcrTools.kt: çift OCR (normal + kontrastı artırılmış/1.5x büyütülmüş görüntü), kalite puanı, iki sonucu birleştirme
- TextCleaner.kt: OCR hatalarını temizler (| -> I, y0u -> you, satır sonu, boşluk, BÜYÜK HARF -> cümle düzeni)
- Glossary.kt + assets/glossary.txt: oyun sözlüğü; isimler çeviriden korunur, OCR'ın 1 harf bozduğu isimler düzeltilir

## Kullanım
- **Dokun:** ekranı çevir. Tekrar dokun: çeviriyi sil.
- **Uzun bas:** menü → *Alan seç*, *Otomatik çeviriyi aç/kapat*, *Çeviriyi sil*, *Durdur*.
- **Alan seçme:** parmakla bir dikdörtgen çiz; sonra yalnız orası okunur ve çevrilir (daha hızlı, daha isabetli). Boş dokunuş alanı kaldırır.
- **Otomatik çeviri:** ekran değişince (yeni diyalog vb.) kendiliğinden yeniden çevirir. Yazı hâlâ yazılıyorsa (daktilo efekti) bitmesini bekler. Balon turkuaz olur.

## Çeviri motorları (ana ekrandan seçilir)
- **Çevrimdışı (ML Kit):** internetsiz, hızlı, kalite orta.
- **Gemini:** ekrandaki tüm yazı bloğu tek istekte, birbirine bağlam olarak gider; oyun sözlüğündeki isimler çevrilmez. En iyi kalite. Ücretsiz anahtar: aistudio.google.com/apikey
- **DeepL:** sözlük terimleri korunur. Ücretsiz anahtar: deepl.com/pro-api
- Bulut motoru hata verirse (internet yok, anahtar yanlış, kota) kendiliğinden çevrimdışıya düşer.
- Anahtarlar yalnız telefonda (uygulamanın özel alanı) saklanır; bulut seçiliyse ekrandaki yazılar Google/DeepL'e gönderilir.

## Sözlüğü düzenleme
`app/src/main/assets/glossary.txt` — her satır `İngilizce terim | isteğe bağlı Türkçe karşılık`.
Karşılık boşsa terim aynen kalır. Yeni karakter/yer çıkınca bu dosyaya satır eklemen yeter.

## Çeviri hata toleransı
- Bir blok çevrilemezse 1 kez tekrar denenir, olmazsa atlanır; diğer yazılar yine çizilir.
- 30 sn içinde bitmezse eldeki sonuç gösterilir, balon takılı kalmaz.
- Aynı metin tekrar çevrilmez (önbellek).

## Bilinen sınırlar
- Henüz derlenip telefonda denenmedi; ilk derlemede küçük düzeltmeler gerekebilir.
- Her dokunuşta tek kare çevrilir (CeBo gibi otomatik sürekli çeviri yok).
- Korumalı (FLAG_SECURE) uygulamalar ekran yakalamada boş görünür.
- Çok süslü fontlarda OCR hâlâ hata yapabilir (çift OCR bunu azaltır, sıfırlamaz).
- Çeviri motoru ML Kit (çevrimdışı); uzun/deyimsel cümlelerde kalite sınırlıdır.
