plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.ekrancevir"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.ekrancevir"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.0")
    // Ekrandaki yazıyı okur (OCR) — model uygulamayla birlikte gelir, internetsiz çalışır
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // İngilizce -> Türkçe çeviri — model bir kez indirilir, sonra internetsiz çalışır
    implementation("com.google.mlkit:translate:17.0.3")
}
