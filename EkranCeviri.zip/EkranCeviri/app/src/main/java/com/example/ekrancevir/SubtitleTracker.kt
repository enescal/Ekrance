package com.example.ekrancevir

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Ekrandaki yazıları zaman içinde izler (altyazı mantığı):
 *  - aynı yazı tekrar çevrilmez, çeviri kutusu yerinden oynamaz;
 *  - yazı hâlâ yazılıyorsa (daktilo efekti) bitmesini bekler;
 *  - bir çeviri en az [minShowMs] ekranda kalır;
 *  - kaynak yazı gidince çeviri [hideDelayMs] sonra kalkar (OCR bir turda kaçırsa hemen silinmez).
 * Android'e bağımlı değildir; zamanlar milisaniye.
 */
class SubtitleTracker(var minShowMs: Long = 2500, var hideDelayMs: Long = 1200) {

    class Box(val l: Int, val t: Int, val r: Int, val b: Int) {
        val w: Int get() = r - l
        val h: Int get() = b - t
        fun area(): Long = max(0, w).toLong() * max(0, h)

        /** Kesişim alanının küçük kutuya oranı (0..1). */
        fun overlap(o: Box): Float {
            val iw = min(r, o.r) - max(l, o.l)
            val ih = min(b, o.b) - max(t, o.t)
            if (iw <= 0 || ih <= 0) return 0f
            val m = min(area(), o.area())
            return if (m <= 0) 0f else (iw.toLong() * ih).toFloat() / m
        }
    }

    /** İzlenen bir çeviri. */
    class Entry(val key: String, var box: Box, var text: String, var bg: Int) {
        var src = ""                         // çevrilen İngilizce yazı ("bir daha çevirme" listesi için)
        var showAt = 0L                      // bu andan itibaren görünür
        var shownAt = 0L                     // gerçekten ilk göründüğü an (0 = henüz değil)
        var missSince = -1L                  // kaynak yazı ilk ne zaman görünmez oldu (-1 = görünüyor)
        var removeAt = Long.MAX_VALUE        // bu andan sonra kalkar (MAX = planlanmadı)
    }

    /** OCR'ın o turda bulduğu bir blok (metin önceden temizlenmiş olmalı). */
    class Seen(val box: Box, val text: String) {
        val key: String = normalize(text)
        internal var replaces: List<Entry> = emptyList()
    }

    private class Cand(val key: String, val count: Int)

    val entries = ArrayList<Entry>()
    private var cands: List<Cand> = emptyList()

    /** Karara bağlanmamış bir şey var: aday bekliyor ya da kaybolan yazı doğrulanıyor. Doğruysa OCR sürmeli. */
    var unsettled = false
        private set

    /**
     * Bir OCR turunun sonucunu işler. Dönen liste: şimdi çevrilmesi gereken YENİ ve KARARLI bloklar.
     * Eşleşen girdilerin çevirisi ve yeri değişmez.
     */
    fun update(now: Long, seen: List<Seen>): List<Seen> {
        val used = HashSet<Entry>()
        val fresh = ArrayList<Seen>()
        for (s in seen) {
            if (s.key.isEmpty()) continue
            var best: Entry? = null
            var bestSim = 0f
            for (e in entries) {
                if (e in used || e.removeAt != Long.MAX_VALUE) continue
                if (s.key.length >= e.key.length + 3 && s.key.startsWith(e.key)) continue   // yazı uzamış: yeni metin say
                if (digitsOf(e.key) != digitsOf(s.key)) continue   // sayı değişti (3/5 -> 4/5): eski çeviri yanlış olur, yeniden çevir
                val sim = similarity(e.key, s.key)
                if (sim > bestSim) { bestSim = sim; best = e }
            }
            if (best != null && bestSim >= MATCH) {
                used += best
                best.missSince = -1L
                if (moved(best.box, s.box)) best.box = s.box        // gerçekten kaymışsa takip et, yoksa yerinde kalsın
            } else {
                fresh += s
            }
        }

        // yeni bloklar: aynı metin ardışık iki turda görülürse (ya da cümle bitmişse) çevrilir
        val ready = ArrayList<Seen>()
        val next = ArrayList<Cand>()
        for (s in fresh) {
            val old = cands.firstOrNull { similarity(it.key, s.key) >= 0.9f }
            val n = (old?.count ?: 0) + 1
            next += Cand(s.key, n)
            if (n >= 2 || looksComplete(s.text)) {
                s.replaces = entries.filter { it !in used && it.box.overlap(s.box) >= 0.3f }
                ready += s
            }
        }
        cands = next

        // kaynağı görünmeyen girdiler: bir süre bekle, sonra kaldırmayı planla
        var waiting = false
        for (e in entries) {
            if (e in used || e.removeAt != Long.MAX_VALUE) continue
            if (e.missSince < 0) e.missSince = now          // ilk kez görünmedi: bekleme başlar (tek tur OCR kaçırması silmez)
            if (now - e.missSince >= hideDelayMs) {
                e.removeAt = if (e.shownAt == 0L) now else max(now, e.shownAt + minShowMs)
            } else {
                waiting = true
            }
        }
        unsettled = waiting || cands.isNotEmpty()
        return ready
    }

    /**
     * Yeni çeviri ekler ya da aynı yazının çevirisini günceller (önizleme -> kesin çeviri).
     * Aynı yerdeki eski yazı gerçekten değiştiyse eskisi en az [minShowMs] görünür, yenisi sonra gelir;
     * yazı yalnız uzamışsa (daktilo) hemen değişir. translation boşsa yalnız izlenir, çizilmez (isimler vb.).
     */
    fun upsert(now: Long, s: Seen, translation: String, bg: Int) {
        val same = entries.firstOrNull { it.key == s.key && it.removeAt == Long.MAX_VALUE }
        if (same != null) {
            same.text = translation
            same.src = s.text
            same.bg = bg
            same.missSince = -1L
            return
        }
        var showAt = now
        for (e in s.replaces) {
            if (e !in entries) continue
            val extension = s.key.startsWith(e.key) || e.key.startsWith(s.key)
            val until = if (extension || e.shownAt == 0L) now else max(now, e.shownAt + minShowMs)
            if (until < e.removeAt) e.removeAt = until
            showAt = max(showAt, e.removeAt)
        }
        val ne = Entry(s.key, s.box, translation, bg)
        ne.src = s.text
        ne.showAt = showAt
        entries += ne
    }

    /** Çeviri sürerken (OCR durmuşken) kaynak yazı "kayboldu" sanılmasın: bekleme sayaçlarını sıfırla. */
    fun touchAll() {
        for (e in entries) if (e.removeAt == Long.MAX_VALUE) e.missSince = -1L
    }

    fun visible(now: Long): List<Entry> =
        entries.filter { it.text.isNotBlank() && it.showAt <= now && it.removeAt > now }

    fun markShown(now: Long) {
        for (e in visible(now)) if (e.shownAt == 0L) e.shownAt = now
    }

    fun purge(now: Long) {
        entries.removeAll { it.removeAt <= now }
    }

    /** Bir sonraki "göster/kaldır" anı (yoksa null). Ekran bu ana göre yeniden çizilir. */
    fun nextEvent(now: Long): Long? {
        var t = Long.MAX_VALUE
        for (e in entries) {
            if (e.showAt > now) t = min(t, e.showAt)
            if (e.removeAt > now && e.removeAt != Long.MAX_VALUE) t = min(t, e.removeAt)
        }
        return if (t == Long.MAX_VALUE) null else t
    }

    fun clear() {
        entries.clear()
        cands = emptyList()
        unsettled = false
    }

    private fun digitsOf(k: String): String = k.filter { it.isDigit() }

    private fun moved(a: Box, b: Box): Boolean =
        abs(a.t - b.t) > max(24, a.h / 2) || abs(a.l - b.l) > max(40, a.w / 4)

    private fun looksComplete(text: String): Boolean {
        val t = text.trimEnd()
        return t.length >= 10 && t.last() in ".!?…\"\u201D"
    }

    companion object {
        private const val MATCH = 0.8f

        fun normalize(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

        /** İki (normalleştirilmiş) metnin benzerliği, 0..1 (Levenshtein). */
        fun similarity(a: String, b: String): Float {
            if (a == b) return 1f
            val n = max(a.length, b.length)
            if (n == 0) return 1f
            if (abs(a.length - b.length) > n * 0.3) return 0f
            val x = if (a.length > 300) a.take(300) else a
            val y = if (b.length > 300) b.take(300) else b
            var prev = IntArray(y.length + 1) { it }
            for (i in 1..x.length) {
                val cur = IntArray(y.length + 1)
                cur[0] = i
                for (j in 1..y.length) {
                    cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (x[i - 1] == y[j - 1]) 0 else 1)
                }
                prev = cur
            }
            return 1f - prev[y.length].toFloat() / max(x.length, y.length)
        }
    }
}
