package com.example.ekrancevir

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * CeBo mantığı: ekranı oku -> yazıyı bul -> çevir -> yazının tam üstüne çiz.
 * Hedef uygulamaya hiçbir şey kurulmaz; yalnız ekran görüntüsü alınır ve üstüne şeffaf katman çizilir.
 */
class CaptureService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var last: Image? = null          // ekranın son karesi
    private var curW = 0
    private var curH = 0

    private var bubble: View? = null
    private var overlay: OverlayView? = null
    private var busy = false

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.TURKISH)
                .build()
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY

        startInForeground()   // Android 14: projection oluşturmadan önce zorunlu

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, "data", Intent::class.java) }
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)
        projection = p

        val (w, h, dpi) = realSize()
        curW = w; curH = h
        reader = newReader(w, h)
        // Android 14'te aynı projection ile yalnız BİR VirtualDisplay kurulabilir; boyut değişince resize kullanıyoruz
        vd = p.createVirtualDisplay(
            "ekran-ceviri", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, main
        )
        showBubble()
        return START_NOT_STICKY
    }

    // ---------- ekran yakalama ----------

    private fun realSize(): Triple<Int, Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Triple(b.width(), b.height(), resources.configuration.densityDpi)
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
        }
    }

    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            last?.close()
            last = img
        }, main)
        return r
    }

    /** Telefon yan çevrildiyse (oyunlar genelde yatay) yakalama boyutunu güncelle. */
    private fun ensureSize() {
        val (w, h, dpi) = realSize()
        if (w == curW && h == curH) return
        curW = w; curH = h
        last?.close(); last = null
        val old = reader
        reader = newReader(w, h)
        vd?.resize(w, h, dpi)
        vd?.surface = reader!!.surface
        old?.close()
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        p.buffer.rewind()
        val pix = p.pixelStride
        val rowPad = p.rowStride - pix * img.width
        val bmp = Bitmap.createBitmap(img.width + rowPad / pix, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(p.buffer)
        return if (rowPad == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
    }

    // ---------- dokununca: oku -> çevir -> çiz ----------

    private fun onTap() {
        if (busy) return
        if (overlay != null) { clearOverlay(); return }   // ikinci dokunuş çeviriyi siler
        busy = true
        bubble?.visibility = View.INVISIBLE                // balon yakalanan görüntüye girmesin
        ensureSize()
        main.postDelayed({ capture() }, 250)
    }

    private fun capture() {
        val img = last
        val bmp = img?.let { toBitmap(it) }
        bubble?.visibility = View.VISIBLE
        if (bmp == null) { busy = false; toast("Ekran alınamadı."); return }
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { translateAll(bmp, it) }
            .addOnFailureListener { busy = false; toast("Yazı okunamadı.") }
    }

    private fun translateAll(bmp: Bitmap, t: Text) {
        val blocks = t.textBlocks.filter { it.boundingBox != null && it.text.count(Char::isLetter) >= 2 }
        if (blocks.isEmpty()) { busy = false; toast("Çevrilecek yazı bulunamadı."); return }
        val out = arrayOfNulls<Item>(blocks.size)
        var left = blocks.size
        blocks.forEachIndexed { i, b ->
            val r = b.boundingBox!!
            translator.translate(b.text.replace('\n', ' '))
                .addOnSuccessListener { tr -> out[i] = Item(r, tr, bgColor(bmp, r)) }
                .addOnCompleteListener {
                    left--
                    if (left == 0) { showOverlay(out.filterNotNull()); busy = false }
                }
        }
    }

    /** Yazının arkasındaki rengi kutunun kenarlarından örnekle; çeviri aynı renkte oturur. */
    private fun bgColor(bmp: Bitmap, r: Rect): Int {
        val pts = listOf(
            r.left to r.top, r.right to r.top, r.left to r.bottom, r.right to r.bottom,
            r.centerX() to r.top, r.centerX() to r.bottom, r.left to r.centerY(), r.right to r.centerY()
        )
        var sr = 0; var sg = 0; var sb = 0
        for ((x0, y0) in pts) {
            val x = (x0 + if (x0 <= r.left) -3 else if (x0 >= r.right) 3 else 0).coerceIn(0, bmp.width - 1)
            val y = (y0 + if (y0 <= r.top) -3 else if (y0 >= r.bottom) 3 else 0).coerceIn(0, bmp.height - 1)
            val c = bmp.getPixel(x, y)
            sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c)
        }
        val n = pts.size
        return Color.rgb(sr / n, sg / n, sb / n)
    }

    // ---------- pencereler ----------

    private fun showOverlay(items: List<Item>) {
        clearOverlay()
        val v = OverlayView(this, items)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        overlay = v
    }

    private fun clearOverlay() {
        overlay?.let { wm.removeView(it) }
        overlay = null
    }

    private fun showBubble() {
        val size = (52 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = "TR"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xE0C2570A.toInt()) }
        }
        val lp = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 16; y = 400 }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> if (abs(e.rawX - sx) > 12 || abs(e.rawY - sy) > 12) {
                    moved = true
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap()
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
    }

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("ceviri", "Ekran Çeviri", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, "ceviri")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Ekran Çeviri çalışıyor")
            .setContentText("Çevirmek için ekrandaki TR balonuna dokun.")
            .addAction(0, "Durdur", stop)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        bubble?.let { wm.removeView(it) }
        clearOverlay()
        last?.close()
        vd?.release()
        reader?.close()
        projection?.stop()
        recognizer.close()
        translator.close()
        super.onDestroy()
    }
}
