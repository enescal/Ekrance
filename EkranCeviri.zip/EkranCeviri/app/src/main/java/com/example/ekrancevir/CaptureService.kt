package com.example.ekrancevir

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Ekranı oku -> yazıyı bul -> çevir -> yazının tam üstüne çiz.
 *  - Dokun: tek kare çevir.  Uzun bas: menü (alan seç / otomatik / durdur).
 *  - Alan seçme: yalnız seçilen dikdörtgen okunur ve çevrilir.
 *  - Otomatik mod: ekran değişince (örn. yeni diyalog) kendiliğinden yeniden çevirir.
 *  - Motor: ML Kit (çevrimdışı), Gemini veya DeepL; bulut hata verirse çevrimdışıya düşer.
 */
class CaptureService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var last: Image? = null          // ekranın son karesi
    private var frameSeq = 0L                 // her yeni karede artar
    private var curW = 0
    private var curH = 0

    private var bubble: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var bubbleBg: GradientDrawable? = null
    private var bubbleSize = 0
    private var overlay: OverlayView? = null
    private var panel: View? = null
    private var areaView: AreaSelectView? = null
    private val areas = ArrayList<Rect>()     // seçili çeviri alanları (ekran koordinatı); boşsa tüm ekran
    private var pickView: IgnorePickView? = null
    private var shownItems: List<Item> = emptyList()   // şu an ekranda çizili çeviriler
    private var ignoreKeys: List<String> = emptyList() // "bir daha çevirme" listesi (normalleştirilmiş anahtarlar)

    private var busy = false
    private var job = 0                       // her çeviri işinde artar; eski işlerin geç sonuçlarını yok sayar
    private var forceFinish: (() -> Unit)? = null

    // otomatik mod
    private var auto = false
    private var sampling = false
    private var forceNext = false
    private var autoOcrCount = 0
    private var lastSig: IntArray? = null
    private var pendingSig: IntArray? = null
    private var lastRects: List<Rect> = emptyList()
    private var lastAutoAt = 0L
    private var ovSig: IntArray? = null           // çeviri katmanı AÇIKKEN alınan son imza (kutuların dışını izlemek için)
    private var lastUnderAt = 0L                  // katmanın altına (gizleyerek) en son ne zaman bakıldı
    private val autoTick = Runnable { autoStep() }
    private val tracker = SubtitleTracker()               // altyazı mantığı: yazı gidene kadar çeviri yerinde kalır
    private var renderedSig = ""
    private val renderTick = Runnable { renderNow() }

    private var lastToast = ""
    private var lastToastAt = 0L

    private val worker = Executors.newSingleThreadExecutor()
    private val net = Executors.newCachedThreadPool()
    private val cache = HashMap<String, String>()   // "motor|metin" -> çeviri
    private val glossary by lazy { Glossary.load(this) }
    private val skipRules by lazy { SkipRules.load(this) }

    // Diyalog hafızası: son çevrilen satırlar (3 dk), bulut çevirisine bağlam olarak gider
    private class Line(val src: String, val tr: String, val at: Long)
    private val history = ArrayList<Line>()

    private fun remember(src: String, tr: String) {
        if (src.length < 8) return
        val now = SystemClock.elapsedRealtime()
        history.removeAll { now - it.at > 180_000 || it.src == src }
        history.add(Line(src.take(240), tr.take(240), now))
        while (history.size > 10) history.removeAt(0)
    }

    private fun recentContext(exclude: List<String>): List<Pair<String, String>> {
        val now = SystemClock.elapsedRealtime()
        return history.filter { now - it.at <= 180_000 && it.src !in exclude }.takeLast(8).map { it.src to it.tr }
    }

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.TURKISH)
                .build()
        )
    }

    companion object {
        private const val UNDER_MIN_MS = 600L     // yeni yazıları daha çabuk yakalamak için alt katmanı daha sık kontrol et
        private const val UNDER_MAX_MS = 1400L    // ekran değişimi küçük olsa bile en geç bu sürede kaynak ekrana bak
        private const val MAX_AREAS = 4          // aynı anda en çok bu kadar çeviri alanı
        private const val HIDE_SETTLE_MS = 80L    // katman gizlenince katmansız kare oluşması için en az bekleme
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        ignoreKeys = Prefs.ignoreList(this).map { it.first }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY

        startInForeground()   // Android 14: projection oluşturmadan önce zorunlu

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, "data", Intent::class.java) }
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, main)
        projection = p

        val (w, h, dpi) = realSize()
        curW = w; curH = h
        reader = newReader(w, h)
        // Android 14'te aynı projection ile yalnız BİR VirtualDisplay kurulabilir; boyut değişince resize kullanıyoruz
        vd = p.createVirtualDisplay(
            "ekran-ceviri", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, main
        )
        showBubble()
        return START_NOT_STICKY
    }

    // ---------- ekran yakalama ----------

    private fun realSize(): Triple<Int, Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Triple(b.width(), b.height(), resources.configuration.densityDpi)
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
        }
    }

    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            last?.close()
            last = img
            frameSeq++
        }, main)
        return r
    }

    /** Telefon yan çevrildiyse (oyunlar genelde yatay) yakalama boyutunu güncelle. */
    private fun ensureSize() {
        val (w, h, dpi) = realSize()
        if (w == curW && h == curH) return
        curW = w; curH = h
        areas.clear(); lastSig = null; pendingSig = null   // koordinatlar geçersiz oldu
        last?.close(); last = null
        val old = reader
        reader = newReader(w, h)
        vd?.resize(w, h, dpi)
        vd?.surface = reader!!.surface
        old?.close()
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        p.buffer.rewind()
        val pix = p.pixelStride
        val rowPad = p.rowStride - pix * img.width
        val bmp = Bitmap.createBitmap(img.width + rowPad / pix, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(p.buffer)
        return if (rowPad == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
    }

    private fun grab(): Bitmap? = try { last?.let { toBitmap(it) } } catch (e: Exception) { null }

    // ---------- dokununca ----------

    private fun onTap() {
        if (busy || areaView != null || pickView != null) return
        dismissPanel()
        if (auto) {                                        // otomatik modda dokunuş = her şeyi sıfırla, hemen yeniden çevir
            resetTracking()
            forceNext = true
            main.removeCallbacks(autoTick)
            main.post(autoTick)
            return
        }
        if (overlay != null) { clearOverlay(); return }    // ikinci dokunuş çeviriyi siler
        busy = true
        bubble?.visibility = View.INVISIBLE                // balon yakalanan görüntüye girmesin
        ensureSize()
        main.postDelayed({ captureManual() }, 250)
    }

    private fun captureManual() {
        val bmp = grab()
        bubble?.visibility = View.VISIBLE
        if (bmp == null) { busy = false; toast("Ekran alınamadı."); return }
        startPipeline(bmp)
    }

    // ---------- otomatik mod ----------

    private fun setAuto(on: Boolean) {
        auto = on
        bubbleBg?.setColor(if (on) 0xE00E8A8F.toInt() else 0xE0C2570A.toInt())
        main.removeCallbacks(autoTick)
        resetTracking()
        if (on) {
            autoOcrCount = 0
            lastSig = null; pendingSig = null; forceNext = true
            toast("Otomatik çeviri açık")
            main.post(autoTick)
        } else {
            toast("Otomatik çeviri kapalı")
        }
    }

    private fun scheduleAuto() {
        main.removeCallbacks(autoTick)
        if (auto) main.postDelayed(autoTick, Prefs.intervalMs(this).toLong())
    }

    private fun autoStep() {
        if (!auto) return
        scheduleAuto()
        if (busy || sampling || areaView != null || pickView != null || panel != null) return
        ensureSize()
        val img = last ?: return
        val ov = overlay
        if (ov == null) { sampling = true; decide(null); return }

        // Çeviri katmanı ekranda. Kaynak yazı katmanın ALTINDA kaldığı için görmek istiyorsak katmanı gizlemek
        // gerekir, ama her turda gizlemek yanıp sönme yapar. Bu yüzden yalnız gerektiğinde gizle:
        //  - karara bağlanmamış bir şey varsa (aday bekliyor / kaybolan yazı doğrulanıyor),
        //  - çeviri kutularının DIŞINDA ekran değiştiyse (en az UNDER_MIN_MS arayla),
        //  - ya da en geç UNDER_MAX_MS'de bir (aynı yerde yeni altyazı gelmiş olabilir).
        val now = SystemClock.elapsedRealtime()
        val sig = try { FrameSignature.of(img) } catch (e: Exception) { return }
        val prev = ovSig
        ovSig = sig
        var look = forceNext || lastSig == null || tracker.unsettled
        if (!look) {
            val since = now - lastUnderAt
            if (since >= UNDER_MAX_MS) {
                look = true
            } else if (since >= UNDER_MIN_MS && prev != null) {
                val boxes = tracker.entries.filter { it.removeAt == Long.MAX_VALUE }.map { boxToRect(it.box) }
                val ex = boxes + listOfNotNull(bubbleRect())
                val m = FrameSignature.maskExcluding(areas.takeIf { it.isNotEmpty() }, ex, curW, curH, dp(12))
                look = FrameSignature.diff(sig, prev, m) > 0.004f
            }
        }
        if (!look) return
        lastUnderAt = now
        sampling = true
        val seq0 = frameSeq
        ov.alpha = 0f
        waitFrame(seq0, SystemClock.elapsedRealtime()) { decide(ov) }
    }

    /**
     * Katman gizlendikten sonra, katmansız bir kare gelene kadar bekle. Oyun 60 fps çiziyorsa "yeni kare" hemen gelir
     * ama o kare katman gizlenmeden önce çizilmiş olabilir; OCR kendi Türkçe çevirimizi okurdu. Bu yüzden hem yeni kare
     * hem en az HIDE_SETTLE_MS geçmesi şart (en çok 300 ms beklenir).
     */
    private fun waitFrame(seq0: Long, startedAt: Long, then: () -> Unit) {
        val el = SystemClock.elapsedRealtime() - startedAt
        if ((frameSeq > seq0 && el >= HIDE_SETTLE_MS) || el >= 300) { then(); return }
        main.postDelayed({ waitFrame(seq0, startedAt, then) }, 8)
    }

    private fun decide(ov: OverlayView?) {
        val img = last
        val sig = try { img?.let { FrameSignature.of(it) } } catch (e: Exception) { null }
        ov?.alpha = 1f                                   // temiz kare elimizde: çeviriyi hemen geri göster (titreme olmasın)
        if (sig == null) { sampling = false; return }
        val ref = lastSig
        // Karara bağlanmamış bir şey varsa (aday bekliyor / kaybolan yazı doğrulanıyor) OCR sürmeli; ayrıca 6 turda bir tam kontrol
        // Her ikinci OCR kararında tam tarama yap. Yalnızca piksel farkına güvenmek,
        // aynı bölgede beliren küçük/yeni diyalogları kaçırabiliyor.
        autoOcrCount++
        val periodicFullScan = autoOcrCount % 2 == 0
        val force = forceNext || ref == null || tracker.unsettled || periodicFullScan
        forceNext = false

        var go = force
        if (!go) {
            val bub = bubbleRect()
            val whole = FrameSignature.mask(areas.takeIf { it.isNotEmpty() }, curW, curH, bub, dp(12))
            val boxes = tracker.entries.map { Rect(it.box.l, it.box.t, it.box.r, it.box.b) }
            // ekranın herhangi bir yerinde değişiklik, ya da çevirisi tutulan yazı kutularında belirgin değişiklik
            go = FrameSignature.diff(sig, ref!!, whole) > 0.004f ||
                (boxes.isNotEmpty() && FrameSignature.diff(sig, ref, FrameSignature.mask(boxes, curW, curH, bub, dp(12))) > 0.06f)
        }
        sampling = false
        if (go) {
            // Tam kareyi yalnız OCR gerçekten gerekiyorsa kopyala (ana iş parçacığında, `last` hâlâ temiz kare)
            val bmp = grab() ?: return
            pendingSig = null
            lastSig = sig
            lastAutoAt = SystemClock.elapsedRealtime()
            startPipeline(bmp)
        }
    }

    /** Değişikliğe bakılacak hücreler: seçili alan > önceki yazı kutuları > tüm ekran. */
    private fun currentMask(): BooleanArray {
        val rects: List<Rect>? = areas.takeIf { it.isNotEmpty() } ?: lastRects.takeIf { it.isNotEmpty() }
        return FrameSignature.mask(rects, curW, curH, bubbleRect(), dp(12))
    }

    private fun bubbleRect(): Rect? {
        val b = bubble ?: return null
        val loc = IntArray(2)
        b.getLocationOnScreen(loc)
        val m = dp(6)
        return Rect(loc[0] - m, loc[1] - m, loc[0] + b.width + m, loc[1] + b.height + m)
    }

    // ---------- işlem hattı: OCR -> temizle -> çevir -> çiz ----------

    private class Work(val rect: Rect, val text: String)

    private fun shift(l: List<OcrBlock>, dx: Int, dy: Int): List<OcrBlock> =
        if (dx == 0 && dy == 0) l else l.map { OcrBlock(Rect(it.rect).apply { offset(dx, dy) }, it.text) }

    private fun startPipeline(bmp: Bitmap) {
        busy = true
        val id = ++job
        // Takılmaya karşı: 30 sn içinde bitmezse eldeki sonucu göster, balonu tekrar kullanılabilir yap
        main.postDelayed({
            if (busy && job == id) {
                forceFinish?.invoke()
                if (busy) { busy = false; toast("Çeviri zaman aşımına uğradı.") }
                job++
            }
        }, if (auto) 15000L else 30000L)

        // Seçili alanlar varsa yalnız onlar okunur (daha hızlı ve isabetli); her alan ayrı okunup sonuçlar birleşir
        val crops = areas.mapNotNull {
            Rect(max(0, it.left), max(0, it.top), min(bmp.width, it.right), min(bmp.height, it.bottom))
                .takeIf { r -> r.width() > 20 && r.height() > 20 }
        }
        val parts: List<Rect?> = if (crops.isEmpty()) listOf(null) else crops

        // Çift OCR: normal görüntü + kontrastı artırılmış/büyütülmüş görüntü; iki sonuç birleştirilir
        val fast = auto                                   // otomatik modda tek OCR: daha hızlı
        val resA = arrayOfNulls<List<OcrBlock>>(parts.size)
        val resB = arrayOfNulls<List<OcrBlock>>(parts.size)
        var pending = parts.size * (if (fast) 1 else 2)
        fun ocrDone() {
            pending--
            if (pending > 0 || job != id) return
            val all = ArrayList<OcrBlock>()
            var any = false
            for (k in parts.indices) {
                val a = resA[k]; val b = resB[k]
                val m = if (a != null && b != null) OcrTools.merge(a, b) else (a ?: b)
                if (m != null) { any = true; all += m }
            }
            if (!any) { busy = false; toast("Yazı okunamadı.") } else translateAll(id, bmp, all)
        }

        for (k in parts.indices) {
            val part = parts[k]
            val cut = if (part == null) null else try {
                Bitmap.createBitmap(bmp, part.left, part.top, part.width(), part.height())
            } catch (e: Exception) { null }
            val base = cut ?: bmp
            val dx = if (cut != null && part != null) part.left else 0
            val dy = if (cut != null && part != null) part.top else 0

            recognizer.process(InputImage.fromBitmap(base, 0)).addOnCompleteListener { task ->
                if (task.isSuccessful) resA[k] = shift(OcrTools.fromMlKit(task.result, 1f), dx, dy)
                ocrDone()
            }

            if (!fast) worker.execute {
                val scale = if (max(base.width, base.height) <= 2600) 1.5f else 1f
                val enh = try { OcrTools.enhance(base, scale) } catch (e: Throwable) { null }
                main.post {
                    if (enh == null) { ocrDone(); return@post }
                    recognizer.process(InputImage.fromBitmap(enh, 0)).addOnCompleteListener { task ->
                        if (task.isSuccessful) resB[k] = shift(OcrTools.fromMlKit(task.result, scale), dx, dy)
                        enh.recycle()
                        ocrDone()
                    }
                }
            }
        }
    }

    /** Temizle -> OCR'ın bozduğu isimleri düzelt -> BÜYÜK HARFİ normalleştir. */
    private fun prepare(raw: String): String =
        TextCleaner.normalizeCaps(glossary.canonicalize(TextCleaner.clean(raw)))

    /**
     * OCR bazen kendi çeviri katmanımızı (ya da oyunun zaten Türkçe menüsünü) okur; bunu İngilizce sanıp
     * tekrar çevirmek anlamsız metin üretir ve döngü yaratır. Türkçe görünen ya da ekranda duran çevirilerimize
     * çok benzeyen blokları atla.
     */
    private fun isOwnOrTurkish(raw: String): Boolean {
        if (TextCleaner.looksTurkish(raw)) return true
        val k = SubtitleTracker.normalize(raw)
        if (k.length < 4) return false
        return tracker.entries.any {
            it.text.isNotBlank() && SubtitleTracker.similarity(SubtitleTracker.normalize(it.text), k) >= 0.75f
        }
    }

    private fun boxToRect(b: SubtitleTracker.Box) = Rect(b.l, b.t, b.r, b.b)

    /** Yazı "bir daha çevirme" listesinde mi? (OCR'ın 1-2 harflik farkları da eşleşir.) */
    private fun isIgnored(text: String): Boolean {
        if (ignoreKeys.isEmpty()) return false
        val k = SubtitleTracker.normalize(text)
        if (k.isEmpty()) return false
        return ignoreKeys.any { it == k || (k.length >= 6 && SubtitleTracker.similarity(it, k) >= 0.88f) }
    }

    /** Otomatik mod: OCR sonucunu izleyiciyle karşılaştır; yalnız YENİ ve KARARLI yazıları çevir. */
    private fun autoReconcile(id: Int, bmp: Bitmap, work: List<Work>) {
        if (job != id) return
        tracker.minShowMs = Prefs.minShowMs(this).toLong()
        tracker.hideDelayMs = Prefs.hideDelayMs(this).toLong()
        val now = SystemClock.elapsedRealtime()
        val seen = work.map {
            SubtitleTracker.Seen(SubtitleTracker.Box(it.rect.left, it.rect.top, it.rect.right, it.rect.bottom), it.text)
        }
        val ready = tracker.update(now, seen)
        if (ready.isEmpty()) { busy = false; renderNow(); return }

        val results = arrayOfNulls<String>(ready.size)
        var finished = false

        fun bgOf(s: SubtitleTracker.Seen): Int =
            try { bgColor(bmp, boxToRect(s.box)) } catch (e: Exception) { Color.BLACK }

        fun finish() {
            if (finished || job != id) return
            finished = true
            forceFinish = null
            busy = false
            val t = SystemClock.elapsedRealtime()
            tracker.touchAll()                                  // çeviri sürerken OCR durdu; kaybolma sayacı yeniden başlasın
            for (i in ready.indices) {
                val s = ready[i]
                val tr = results[i] ?: continue
                val same = tr.trim().equals(s.text.trim(), ignoreCase = true)
                tracker.upsert(t, s, if (same) "" else tr, bgOf(s))   // isim gibi aynı kalanlar yalnız izlenir
                if (!same) remember(s.text, tr)
            }
            renderNow()
        }
        // Bulut cevabı gelene kadar çevrimdışı çeviriyi önizleme olarak göster
        fun preview(quick: Array<String?>) {
            if (finished || job != id) return
            val t = SystemClock.elapsedRealtime()
            for (i in ready.indices) {
                val tr = quick[i] ?: continue
                if (tr.trim().equals(ready[i].text.trim(), ignoreCase = true)) continue
                tracker.upsert(t, ready[i], tr, bgOf(ready[i]))
            }
            renderNow()
        }
        forceFinish = { finish() }
        translateBatch(ready.map { it.text }, id, results, { q -> preview(q) }) { finish() }
    }

    /** İzleyicinin durumuna göre ekranı çiz. Değişiklik yoksa hiçbir şeyi yeniden çizmez (titreme/kayma olmaz). */
    private fun renderNow() {
        if (sampling) { main.postDelayed(renderTick, 40); return }      // ekran görüntüsü alınırken katmanı değiştirme
        val now = SystemClock.elapsedRealtime()
        tracker.purge(now)
        tracker.markShown(now)
        val vis = tracker.visible(now)
        val sig = vis.joinToString("|") { "${it.key}:${it.box.l},${it.box.t}:${it.text.hashCode()}" }
        if (sig != renderedSig) {
            if (vis.isEmpty()) clearOverlay()
            else showOverlay(vis.map { Item(boxToRect(it.box), it.text, it.bg, it.src) })
            renderedSig = sig
        }
        main.removeCallbacks(renderTick)
        tracker.nextEvent(now)?.let { main.postDelayed(renderTick, max(30L, it - now)) }
    }

    /** Çeviri katmanını ve izlenen her şeyi sıfırla. */
    private fun resetTracking() {
        main.removeCallbacks(renderTick)
        tracker.clear()
        clearOverlay()
    }

    private fun translateAll(id: Int, bmp: Bitmap, found: List<OcrBlock>) {
        val bub = bubbleRect()
        val work = found
            .filter { bub == null || !Rect.intersects(it.rect, bub) }          // balonun kendi "TR" yazısını çevirme
            .filter { !skipRules.skip(it.text) }                               // UID, sayı, süre, istatistik... çevrilmez
            .filter { !isOwnOrTurkish(it.text) }                               // kendi çeviri katmanımız / zaten Türkçe yazı
            .map { Work(it.rect, prepare(it.text)) }
            .filter { it.text.count(Char::isLetter) >= 2 }
            .filter { !isIgnored(it.text) }                                    // "bir daha çevirme" listesindekiler
        if (auto) { autoReconcile(id, bmp, work); return }
        if (work.isEmpty()) {
            lastRects = emptyList()
            busy = false
            if (auto) clearOverlay() else toast("Çevrilecek yazı bulunamadı.")
            return
        }

        val results = arrayOfNulls<String>(work.size)
        var finished = false

        fun finish() {
            if (finished || job != id) return
            finished = true
            forceFinish = null
            busy = false
            val items = ArrayList<Item>()
            var failed = 0
            for (i in work.indices) {
                val tr = results[i]
                if (tr == null) { failed++; continue }
                if (tr.trim().equals(work[i].text.trim(), ignoreCase = true)) continue   // aynıysa (isim vb.) çizmeye gerek yok
                try {
                    items += Item(work[i].rect, tr, bgColor(bmp, work[i].rect), work[i].text)
                } catch (e: Exception) {
                    failed++                                                              // tek blok patlarsa diğerleri durmasın
                }
            }
            lastRects = work.map { it.rect }
            for (i in work.indices) {
                val tr = results[i] ?: continue
                if (!tr.trim().equals(work[i].text.trim(), ignoreCase = true)) remember(work[i].text, tr)
            }
            when {
                items.isNotEmpty() -> {
                    showOverlay(items)
                    if (failed > 0 && !auto) toast("$failed yazı çevrilemedi.")
                }
                failed > 0 -> toast("Çeviri yapılamadı. Model inmiş mi, internet/anahtar tamam mı?")
                else -> { if (auto) clearOverlay() else toast("Çevrilecek yazı bulunamadı.") }
            }
        }
        // Bulut çevirisi gelene kadar çevrimdışı çeviriyi hemen göster (hızlı his)
        fun preview(quick: Array<String?>) {
            if (finished || job != id) return
            val items = ArrayList<Item>()
            for (i in work.indices) {
                val tr = quick[i] ?: continue
                if (tr.trim().equals(work[i].text.trim(), ignoreCase = true)) continue
                try { items += Item(work[i].rect, tr, bgColor(bmp, work[i].rect), work[i].text) } catch (e: Exception) { }
            }
            if (items.isNotEmpty()) showOverlay(items)
        }
        forceFinish = { finish() }                // zaman aşımında eldeki sonuçla bitir
        translateBatch(work.map { it.text }, id, results, { q -> preview(q) }) { finish() }
    }

    // ---------- çeviri motorları ----------

    private fun toast(t: String) {
        val now = SystemClock.elapsedRealtime()
        if (t == lastToast && now - lastToastAt < 5000) return       // otomatik modda aynı uyarı sürekli çıkmasın
        lastToast = t; lastToastAt = now
        Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    }

    /**
     * Gemini/DeepL seçiliyse tüm bloklar TEK istekte gider (bağlam korunur); hata olursa çevrimdışı ML Kit'e düşer.
     * results dizisi ilerledikçe dolar, hepsi bitince done() çağrılır.
     */
    private fun translateBatch(texts: List<String>, id: Int, results: Array<String?>, onQuick: (Array<String?>) -> Unit, done: () -> Unit) {
        val eng = Prefs.engine(this)
        val gKey = Prefs.geminiKey(this)
        val dKey = Prefs.deeplKey(this)
        val gModel = Prefs.geminiModel(this)
        val cloud = (eng == Prefs.ENGINE_GEMINI && gKey.isNotEmpty()) || (eng == Prefs.ENGINE_DEEPL && dKey.isNotEmpty())
        if (!cloud && eng != Prefs.ENGINE_MLKIT) toast("API anahtarı girilmemiş, çevrimdışı çeviri kullanılıyor.")
        val tag = if (cloud) eng.toString() else "0"

        if (cache.size > 600) cache.clear()
        val pending = ArrayList<Int>()
        for (i in texts.indices) {
            val c = cache["$tag|${texts[i]}"]
            if (c != null) results[i] = c else pending += i
        }
        if (pending.isEmpty()) { done(); return }

        fun viaMlKit(idx: List<Int>) {
            var left = idx.size
            if (left == 0) { done(); return }
            for (i in idx) {
                translateText(texts[i]) { tr ->
                    if (job != id) return@translateText
                    if (tr != null) { results[i] = tr; cache["0|${texts[i]}"] = tr }
                    left--
                    if (left == 0) done()
                }
            }
        }

        if (!cloud) { viaMlKit(pending); return }

        // Bulut cevabı gelirken çevrimdışı çeviri de çalışsın; ilk o gelirse önizleme olarak gösterilir
        var cloudDone = false
        val quick = arrayOfNulls<String>(texts.size)
        run {
            var left = pending.size
            for (i in pending) {
                translateText(texts[i]) { tr ->
                    if (job != id || cloudDone) return@translateText
                    if (tr != null) quick[i] = tr
                    left--
                    if (left == 0) onQuick(quick)
                }
            }
        }

        val src = pending.map { texts[it] }
        val ctx = recentContext(texts)
        val terms = glossary.termsIn(src + ctx.map { it.first })
        net.execute {
            try {
                val out = if (eng == Prefs.ENGINE_GEMINI) CloudTranslators.gemini(gKey, gModel, src, terms, ctx)
                else CloudTranslators.deepl(dKey, src, ctx) { glossary.wrapXml(it) }
                main.post {
                    cloudDone = true
                    if (job != id) return@post
                    pending.forEachIndexed { k, i ->
                        val t = out[k]
                        if (t.isNotBlank()) {
                            val fixed = glossary.fixSuffixes(t)        // Yinlin'a -> Yinlin'e gibi ek hatalarını düzelt
                            results[i] = fixed; cache["$tag|${texts[i]}"] = fixed
                        }
                    }
                    val miss = pending.filter { results[it] == null }
                    if (miss.isEmpty()) done() else viaMlKit(miss)
                }
            } catch (e: Exception) {
                main.post {
                    cloudDone = true
                    if (job != id) return@post
                    toast("Bulut çevirisi başarısız (${e.message?.take(90)}). Çevrimdışıya geçildi.")
                    viaMlKit(pending)
                }
            }
        }
    }

    /** ML Kit: sözlükle koruyarak çevirir; yer tutucu bozulursa korumasız çeviriye düşer; hata olursa 1 kez tekrar dener. */
    private fun translateText(clean: String, cb: (String?) -> Unit) {
        val (prot, repl) = glossary.protect(clean)

        fun plain() = runTranslate(clean) { tr -> cb(tr?.let { glossary.fixSuffixes(it) }) }

        if (repl.isEmpty()) { plain(); return }
        if (glossary.onlyTerms(prot)) { cb(glossary.restore(prot, repl) ?: clean); return }
        runTranslate(prot) { tr ->
            val restored = tr?.let { glossary.restore(it, repl) }
            if (restored != null) cb(restored) else plain()
        }
    }

    private fun runTranslate(text: String, retry: Boolean = true, cb: (String?) -> Unit) {
        try {
            translator.translate(text)
                .addOnSuccessListener { cb(it.takeIf { s -> s.isNotBlank() }) }
                .addOnFailureListener {
                    if (retry) main.postDelayed({ runTranslate(text, false, cb) }, 300) else cb(null)
                }
        } catch (e: Exception) {
            cb(null)
        }
    }

    /** Yazının arkasındaki rengi kutunun kenarlarından örnekle; çeviri aynı renkte oturur. */
    private fun bgColor(bmp: Bitmap, r: Rect): Int {
        val pts = listOf(
            r.left to r.top, r.right to r.top, r.left to r.bottom, r.right to r.bottom,
            r.centerX() to r.top, r.centerX() to r.bottom, r.left to r.centerY(), r.right to r.centerY()
        )
        var sr = 0; var sg = 0; var sb = 0
        for ((x0, y0) in pts) {
            val x = (x0 + if (x0 <= r.left) -3 else if (x0 >= r.right) 3 else 0).coerceIn(0, bmp.width - 1)
            val y = (y0 + if (y0 <= r.top) -3 else if (y0 >= r.bottom) 3 else 0).coerceIn(0, bmp.height - 1)
            val c = bmp.getPixel(x, y)
            sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c)
        }
        val n = pts.size
        return Color.rgb(sr / n, sg / n, sb / n)
    }

    // ---------- pencereler ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showOverlay(items: List<Item>) {
        val old = overlay
        val v = OverlayView(this, items)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        overlay = v
        shownItems = items
        ovSig = null
        old?.let { try { wm.removeView(it) } catch (e: Exception) { } }
    }

    private fun clearOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        overlay = null
        shownItems = emptyList()
        ovSig = null
        renderedSig = ""
    }

    private fun showBubble() {
        val size = dp(52)
        bubbleSize = size
        val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xE0C2570A.toInt()) }
        bubbleBg = bg
        val tv = TextView(this).apply {
            text = "TR"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = bg
        }
        val lp = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 16; y = 400 }
        bubbleLp = lp

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        var moved = false; var longDone = false
        val longPress = Runnable { if (!moved) { longDone = true; showPanel() } }
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; longDone = false
                    main.postDelayed(longPress, 500)
                }
                MotionEvent.ACTION_MOVE -> if (abs(e.rawX - sx) > 12 || abs(e.rawY - sy) > 12) {
                    if (!moved) { moved = true; main.removeCallbacks(longPress) }
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longPress)
                    if (!moved && !longDone) onTap()
                }
                MotionEvent.ACTION_CANCEL -> main.removeCallbacks(longPress)
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
    }

    // ---------- uzun basınca açılan menü ----------

    private fun showPanel() {
        dismissPanel()
        val b = bubbleLp ?: return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xF2101828.toInt())
                setStroke(dp(1), 0x33FFFFFF)
            }
        }
        fun item(label: String, action: () -> Unit) {
            box.addView(TextView(this).apply {
                text = label
                textSize = 15f
                setTextColor(Color.WHITE)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener { dismissPanel(); action() }
            })
        }
        item(if (areas.isEmpty()) "Alan seç" else "Alan ekle (${areas.size}/$MAX_AREAS)") { startAreaSelect() }
        if (areas.isNotEmpty()) item("Alanları kaldır (tüm ekran)") {
            areas.clear(); lastSig = null; pendingSig = null
            resetTracking()
            if (auto) forceNext = true
            toast("Alanlar kaldırıldı, tüm ekran çevrilir.")
        }
        item("Bir daha çevirme…") { startIgnorePick() }
        item(if (auto) "Otomatik çeviriyi kapat" else "Otomatik çeviriyi aç") { setAuto(!auto) }
        item("Ekrandaki çeviriyi sil") { resetTracking() }
        item("Durdur") { stopSelf() }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = max(0, min(b.x + bubbleSize + dp(8), curW - dp(230)))
            y = b.y
        }
        box.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) { dismissPanel(); true } else false
        }
        wm.addView(box, lp)
        panel = box
    }

    private fun dismissPanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        panel = null
    }

    // ---------- alan seçme ----------

    private fun startAreaSelect() {
        if (areaView != null || pickView != null) return
        if (areas.size >= MAX_AREAS) { toast("En çok $MAX_AREAS alan seçilebilir. Önce alanları kaldır."); return }
        val v = AreaSelectView(this, areas.toList()) { r -> endAreaSelect(r) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        areaView = v
    }

    private fun endAreaSelect(r: Rect?) {
        areaView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        areaView = null
        if (r != null) {
            // Yeni alan eskilerle çakışıyorsa hepsi tek alana birleşir (aynı yazı iki kez okunmasın)
            val merged = Rect(r)
            val iter = areas.iterator()
            while (iter.hasNext()) {
                val o = iter.next()
                if (Rect.intersects(o, merged)) { merged.union(o); iter.remove() }
            }
            areas.add(merged)
            toast(if (areas.size == 1) "Alan ayarlandı: artık yalnız burası çevrilir." else "Alan eklendi (${areas.size}).")
        } else {
            toast("Alan seçilmedi.")
        }
        lastSig = null; pendingSig = null
        resetTracking()
        if (auto) forceNext = true
    }

    // ---------- bir daha çevirme ----------

    /** Ekrandaki çevirilere çerçeve çizer; dokunulanın İngilizce kaynağı kalıcı listeye eklenir. */
    private fun startIgnorePick() {
        if (areaView != null || pickView != null) return
        val items = shownItems.filter { it.src.isNotBlank() }
        if (items.isEmpty()) {
            toast("Ekranda çeviri yok. Önce çevir, sonra çevrilmesini istemediğin yazıyı seç.")
            return
        }
        val v = IgnorePickView(this, items) { picked -> endIgnorePick(picked) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        pickView = v
    }

    private fun endIgnorePick(picked: Item?) {
        pickView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        pickView = null
        if (picked == null) return
        val key = SubtitleTracker.normalize(picked.src)
        Prefs.addIgnore(this, key, picked.src)
        ignoreKeys = Prefs.ignoreList(this).map { it.first }
        // Ekrandan hemen kaldır: izleyiciden sil, katmanı yenile (kalan çeviriler yerinde kalır)
        tracker.entries.removeAll { SubtitleTracker.normalize(it.src) == key }
        val rest = shownItems.filter { SubtitleTracker.normalize(it.src) != key }
        renderedSig = ""
        if (auto) renderNow() else if (rest.isEmpty()) clearOverlay() else showOverlay(rest)
        toast("Bir daha çevrilmeyecek. (Liste ana ekrandan düzenlenir.)")
    }

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("ceviri", "Ekran Çeviri", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, CaptureService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, "ceviri")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Ekran Çeviri çalışıyor")
            .setContentText("Dokun: çevir • Uzun bas: alan seç / otomatik")
            .addAction(0, "Durdur", stop)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    override fun onDestroy() {
        auto = false
        main.removeCallbacks(autoTick)
        main.removeCallbacks(renderTick)
        job++
        dismissPanel()
        areaView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        pickView?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        clearOverlay()
        worker.shutdownNow()
        net.shutdownNow()
        last?.close()
        vd?.release()
        reader?.close()
        projection?.stop()
        recognizer.close()
        translator.close()
        super.onDestroy()
    }
}
