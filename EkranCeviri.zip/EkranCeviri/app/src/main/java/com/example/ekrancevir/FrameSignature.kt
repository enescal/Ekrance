package com.example.ekrancevir

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.abs

/** Ekran karesinin küçük parlaklık "parmak izi". Otomatik modda "yazı değişti mi?" kontrolü için. */
object FrameSignature {
    const val GW = 128
    const val GH = 72

    fun of(bmp: Bitmap): IntArray {
        var cur = bmp
        var owned = false
        // Önce kademeli yarıya indir (ortalama alır), sonra hedef ızgaraya ölçekle
        while (cur.width >= GW * 2 && cur.height >= GH * 2) {
            val next = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (owned && cur !== next) cur.recycle()
            cur = next
            owned = true
        }
        val s = Bitmap.createScaledBitmap(cur, GW, GH, true)
        val px = IntArray(GW * GH)
        s.getPixels(px, 0, GW, 0, 0, GW, GH)
        if (s !== cur && s !== bmp) s.recycle()
        if (owned && cur !== bmp) cur.recycle()
        return IntArray(px.size) {
            val c = px[it]
            (299 * Color.red(c) + 587 * Color.green(c) + 114 * Color.blue(c)) / 1000
        }
    }

    /** Karşılaştırılacak hücreler. rects == null ise tüm ekran. exclude (balon gibi) hücreleri dışarıda bırakır. */
    fun mask(rects: List<Rect>?, w: Int, h: Int, exclude: Rect?, padPx: Int): BooleanArray {
        val m = BooleanArray(GW * GH)
        if (w <= 0 || h <= 0) { m.fill(true); return m }
        fun mark(r: Rect, v: Boolean, pad: Int) {
            val x0 = ((r.left - pad).toLong() * GW / w).toInt().coerceIn(0, GW - 1)
            val x1 = ((r.right + pad).toLong() * GW / w).toInt().coerceIn(0, GW - 1)
            val y0 = ((r.top - pad).toLong() * GH / h).toInt().coerceIn(0, GH - 1)
            val y1 = ((r.bottom + pad).toLong() * GH / h).toInt().coerceIn(0, GH - 1)
            for (y in y0..y1) for (x in x0..x1) m[y * GW + x] = v
        }
        if (rects == null) m.fill(true) else for (r in rects) mark(r, true, padPx)
        if (exclude != null) mark(exclude, false, 8)
        return m
    }

    /** Maskedeki hücrelerin kaçta kaçı belirgin değişmiş (0..1). */
    fun diff(a: IntArray, b: IntArray, mask: BooleanArray): Float {
        var n = 0
        var d = 0
        for (i in a.indices) {
            if (!mask[i]) continue
            n++
            if (abs(a[i] - b[i]) > 18) d++
        }
        return if (n == 0) 0f else d.toFloat() / n
    }
}
