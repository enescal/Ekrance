package com.example.ekrancevir

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Bulut çeviri motorları. Hepsi ARKA PLAN iş parçacığında çağrılmalı (ağ kullanır). */
object CloudTranslators {

    class Fail(msg: String) : Exception(msg)

    /**
     * Gemini: ekrandaki TÜM yazı blokları tek istekte gider; model hepsini birbirine bağlam olarak görür.
     * Sözlükteki isimler istemde "çevirme" diye verilir.
     */
    fun gemini(
        key: String, model: String, texts: List<String>, terms: List<String>,
        ctx: List<Pair<String, String>>
    ): List<String> {
        val termsText = if (terms.isEmpty()) "" else
            "Keep these proper names and game terms exactly as written, never translate them: ${terms.joinToString(", ")}. "
        val ctxText = if (ctx.isEmpty()) "" else
            "For context only, these lines were shown to the player just before (English => Turkish). " +
                "Use them to keep names, pronouns, tone and terminology consistent, and NEVER include them in the output: " +
                ctx.joinToString(" | ") { it.first + " => " + it.second } + ". "
        val sys = "You are a professional game localizer translating from English to Turkish for the game Wuthering Waves. " +
            "The input is a JSON array of text blocks OCR'd from ONE screenshot (UI labels, dialogue, item descriptions). " +
            "Use all blocks as context for each other. Translate every block into natural, fluent Turkish and silently fix obvious OCR mistakes. " +
            termsText +
            "Do not change numbers, percentages or symbols. Keep each translation about as short as the original so it fits on screen. " +
            "Return unchanged any block that is a user ID (UID), version string, timer, stat value or player name. " +
            "A short block that is only a character or NPC name is a speaker label: return it unchanged. " +
            "Dialogue is spoken aloud by characters: write natural, conversational Turkish and keep each character's tone consistent. " +
            ctxText +
            "Return ONLY a JSON array of strings with exactly ${texts.size} items, in the same order."

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put(
                "contents", JSONArray().put(
                    JSONObject().put("role", "user").put(
                        "parts", JSONArray().put(JSONObject().put("text", JSONArray(texts).toString()))
                    )
                )
            )
            .put(
                "generationConfig", JSONObject()
                    .put("temperature", 0.2)
                    .put("responseMimeType", "application/json")
                    .put("responseSchema", JSONObject().put("type", "ARRAY").put("items", JSONObject().put("type", "STRING")))
            )

        val resp = post(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            body.toString(),
            mapOf("x-goog-api-key" to key, "Content-Type" to "application/json")
        )

        val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (!p.optBoolean("thought", false)) sb.append(p.optString("text", ""))
        }
        var t = sb.toString().trim()
        if (t.startsWith("```")) t = t.substringAfter('\n').substringBeforeLast("```").trim()
        val arr = JSONArray(t)
        if (arr.length() != texts.size) throw Fail("Gemini ${arr.length()} satır döndürdü, ${texts.size} bekleniyordu")
        return List(arr.length()) { arr.getString(it) }
    }

    /** DeepL: sözlük terimleri <x>…</x> içine alınır, ignore_tags ile çevrilmeden aynen kalır. */
    fun deepl(key: String, texts: List<String>, ctx: List<Pair<String, String>>, wrap: (String) -> String): List<String> {
        if (ctx.isEmpty()) return deeplCall(key, texts, "", wrap)
        return try {
            deeplCall(key, texts, ctx.joinToString("\n") { it.first }, wrap)
        } catch (e: Fail) {
            if (e.message?.startsWith("HTTP 400") == true) deeplCall(key, texts, "", wrap) else throw e   // bağlam reddedilirse bağlamsız dene
        }
    }

    private fun deeplCall(key: String, texts: List<String>, context: String, wrap: (String) -> String): List<String> {
        val host = if (key.endsWith(":fx")) "api-free.deepl.com" else "api.deepl.com"
        val body = JSONObject()
            .put("text", JSONArray(texts.map(wrap)))
            .put("source_lang", "EN")
            .put("target_lang", "TR")
            .put("tag_handling", "xml")
            .put("ignore_tags", JSONArray().put("x"))
        if (context.isNotEmpty()) body.put("context", context)
        val resp = post(
            "https://$host/v2/translate",
            body.toString(),
            mapOf("Authorization" to "DeepL-Auth-Key $key", "Content-Type" to "application/json")
        )
        val arr = JSONObject(resp).getJSONArray("translations")
        if (arr.length() != texts.size) throw Fail("DeepL ${arr.length()} satır döndürdü, ${texts.size} bekleniyordu")
        return List(arr.length()) { unxml(arr.getJSONObject(it).getString("text")) }
    }

    fun unxml(s: String): String = s.replace("<x>", "").replace("</x>", "")
        .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")

    private fun post(url: String, body: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 25000
            c.doOutput = true
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw Fail("HTTP $code ${text.take(160)}")
            return text
        } finally {
            c.disconnect()
        }
    }
}
