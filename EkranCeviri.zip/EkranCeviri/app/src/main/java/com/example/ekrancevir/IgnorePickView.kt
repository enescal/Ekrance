package com.example.ekrancevir

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View

/**
 * "Bir daha çevirme": ekrandaki çevirilerin çevresine çerçeve çizer; dokunulan çevirinin kaynağı listeye eklenir.
 * Çeviri olmayan yere dokunmak işlemi iptal eder.
 */
class IgnorePickView(ctx: Context, private val items: List<Item>, private val onDone: (Item?) -> Unit) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val dim = Paint().apply { color = 0x66000000 }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F87171"); style = Paint.Style.STROKE; strokeWidth = 3f * d
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 15f * d; textAlign = Paint.Align.CENTER
    }

    private fun hit(x: Float, y: Float): Item? {
        val pad = (10 * d).toInt()
        return items.filter { it.src.isNotBlank() }.firstOrNull {
            Rect(it.rect).apply { inset(-pad, -pad) }.contains(x.toInt(), y.toInt())
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onDone(hit(e.rawX, e.rawY))
        if (e.actionMasked == MotionEvent.ACTION_CANCEL) onDone(null)
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
        canvas.drawRect(loc[0].toFloat(), loc[1].toFloat(), loc[0] + width.toFloat(), loc[1] + height.toFloat(), dim)
        for (item in items) {
            if (item.src.isBlank()) continue
            canvas.drawRect(item.rect.left - 6f * d, item.rect.top - 6f * d, item.rect.right + 6f * d, item.rect.bottom + 6f * d, stroke)
        }
        val cx = loc[0] + width / 2f
        canvas.drawText("Bir daha çevrilmesin istediğin yazıya dokun", cx, loc[1] + 90f * d, hint)
        canvas.drawText("(boş yere dokunmak iptal eder)", cx, loc[1] + 90f * d + 22f * d, hint)
    }
}
