package com.example.ekrancevir

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Ekranda bulunan bir yazı bloğu: yeri, Türkçesi ve arkasındaki renk. */
data class Item(val rect: Rect, val text: String, val bg: Int)

/** Ekranın tamamını kaplayan şeffaf katman. Dokunmaları geçirir, yalnız çevrilmiş yazıları çizer. */
class OverlayView(ctx: Context, private val items: List<Item>) : View(ctx) {

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }

    private fun lum(c: Int) = 0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)

    override fun onDraw(canvas: Canvas) {
        // Pencerenin ekrandaki konumunu düzelt: kutular gerçek ekran koordinatında
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())

        val pad = 6
        for (item in items) {
            val r = item.rect
            val w = max(r.width(), 100)
            textPaint.color = if (lum(item.bg) < 140) Color.WHITE else Color.BLACK

            // Yazıyı kutuya sığdır: büyükten küçüğe dene
            var size = min(r.height().toFloat(), 120f)
            var layout: StaticLayout
            while (true) {
                textPaint.textSize = size
                layout = StaticLayout.Builder.obtain(item.text, 0, item.text.length, textPaint, w)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL).build()
                if (layout.height <= r.height() + pad || size <= 18f) break
                size -= 2f
            }

            val h = max(layout.height, r.height())
            bgPaint.color = item.bg
            bgPaint.alpha = 235
            canvas.drawRoundRect(
                RectF(r.left - pad.toFloat(), r.top - pad.toFloat(), (r.left + w + pad).toFloat(), (r.top + h + pad).toFloat()),
                8f, 8f, bgPaint
            )
            canvas.save()
            canvas.translate(r.left.toFloat(), r.top + (h - layout.height) / 2f)
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
