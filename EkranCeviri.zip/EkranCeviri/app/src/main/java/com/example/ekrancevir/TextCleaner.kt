package com.example.ekrancevir

/** OCR'ın bozduğu İngilizce metni çeviriden önce toparlar. Android'e bağımlı değil. */
object TextCleaner {

    private val hyphenBreak = Regex("([A-Za-z])-\\s*\\n\\s*([a-z])")
    private val newlines = Regex("\\s*\\n\\s*")
    private val spaces = Regex("[ \\t]{2,}")
    private val pipeInWord = Regex("(?<=[a-z])\\|(?=[a-z])")
    private val pipeLead = Regex("(?<![A-Za-z0-9])\\|(?=[A-Za-z'])")
    private val pipeAlone = Regex("(?<![A-Za-z0-9])\\|(?![A-Za-z0-9])")
    private val zeroInWord = Regex("(?<=[A-Za-z])0(?=[A-Za-z])")
    private val oneInWord = Regex("(?<=[A-Za-z])1(?=[A-Za-z])")
    private val lContraction = Regex("\\bl(?='(?:m|ll|ve|d)\\b)")
    private val lVerb = Regex(
        "\\bl(?=\\s+(?:am|was|will|have|had|can|could|would|should|think|know|need|want|do|did|see|feel|guess|hope|believe|must|just|don't|didn't|can't)\\b)"
    )
    private val lookalike = Regex("\\bl[fnst]\\b")
    private val spaceBeforePunct = Regex("\\s+([,.!?;:])")
    private val missingSpace = Regex("([,;!?])(?=[A-Za-z])")
    private val dotGlued = Regex("(?<=[a-z]{2})\\.(?=[A-Z][a-z])")
    private val leadJunk = Regex("^[^A-Za-z0-9\"'(\\[]+")
    private val tailJunk = Regex("[^A-Za-z0-9.!?…\"')\\]%]+$")

    fun clean(raw: String): String {
        var s = raw
            .replace('\u2019', '\'').replace('\u2018', '\'').replace('\u02BC', '\'')
            .replace('\u201C', '"').replace('\u201D', '"')
            .replace('\u00A0', ' ')
            .replace("\u200B", "")

        s = hyphenBreak.replace(s, "$1$2")        // "wo-\nrd" -> "word"
        s = newlines.replace(s, " ")               // satır sonlarını boşluk yap
        s = pipeInWord.replace(s, "l")             // he|p -> help
        s = pipeLead.replace(s, "I")               // |'m -> I'm
        s = pipeAlone.replace(s, "I")              // | -> I
        s = zeroInWord.replace(s, "o")             // y0u -> you
        s = oneInWord.replace(s, "l")              // he1p -> help
        s = lContraction.replace(s, "I")           // l'm -> I'm
        s = lVerb.replace(s, "I")                  // l think -> I think

        // lt / lf / ln / ls -> It / If / In / Is (cümle başındaysa büyük harf)
        val src = s
        s = lookalike.replace(src) { m ->
            val fixed = when (m.value) { "lf" -> "if"; "ln" -> "in"; "ls" -> "is"; else -> "it" }
            val before = src.substring(0, m.range.first).trimEnd()
            val sentenceStart = before.isEmpty() || before.last() in ".!?…\""
            if (sentenceStart) fixed.replaceFirstChar { it.uppercase() } else fixed
        }

        s = spaceBeforePunct.replace(s, "$1")
        s = missingSpace.replace(s, "$1 ")
        s = dotGlued.replace(s, ". ")
        s = spaces.replace(s, " ")
        s = leadJunk.replace(s, "")
        s = tailJunk.replace(s, "")
        return s.trim()
    }

    /** BÜTÜN HARF BÜYÜK yazıları cümle düzenine çevir; çeviri modeli büyük harfte kötü çalışıyor. */
    fun normalizeCaps(s: String): String {
        val letters = s.count { it.isLetter() }
        if (letters < 6) return s
        val upper = s.count { it.isUpperCase() }
        if (upper.toFloat() / letters < 0.8f) return s
        var t = s.lowercase()
        t = Regex("(^|[.!?…]\\s+)([a-z])").replace(t) { it.groupValues[1] + it.groupValues[2].uppercase() }
        t = Regex("\\bi\\b").replace(t, "I")
        return t
    }
}
