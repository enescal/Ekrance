package com.example.ekrancevir

/**
 * İsimlere Türkçe hâl eki (Yinlin'e, Jinhsi'nin, Brant'tan...). Android'e bağımlı değildir, çevrimdışı çalışır.
 * Büyük/ince ünlü uyumu, kaynaştırma harfi (y, n) ve sert ünsüz (t/d) kuralları isme göre yeniden kurulur;
 * böylece çeviri motoru eki yanlış getirse de (Yinlin'a, Verina'ya yerine Verina'ya...) düzelir.
 */
object TurkishSuffix {

    enum class Case { DAT, ACC, GEN, LOC, ABL, INS }

    /** Tırnaktan sonra gelebilecek ek biçimleri (uzundan kısaya). Sonda harf gelmemeli. */
    const val SUFFIX_ALT =
        "nin|nın|nun|nün|yla|yle|dan|den|tan|ten|ya|ye|na|ne|yi|yı|yu|yü|in|ın|un|ün|da|de|ta|te|la|le|a|e|i|ı|u|ü"

    private val VOWELS = "aeıioöuü"
    private val HARD = "çfhkpsştxc"

    /** Okunuşu yazılışından ayrı olan isimler (küçük harf). */
    private val ACCENT = mapOf(
        'é' to 'e', 'è' to 'e', 'ê' to 'e', 'ë' to 'e', 'á' to 'a', 'à' to 'a', 'â' to 'a', 'ä' to 'a',
        'í' to 'i', 'ì' to 'i', 'î' to 'i', 'ï' to 'i', 'ó' to 'o', 'ò' to 'o', 'ô' to 'o',
        'ú' to 'u', 'ù' to 'u', 'û' to 'u'
    )

    private val SOUND = mapOf(
        "phoebe" to "fibi",
        "hecate" to "hekate",
        "lucy" to "lusi",
        "lily" to "lili"
    )

    fun classify(suffix: String): Case? = when (suffix.lowercase()) {
        "a", "e", "ya", "ye", "na", "ne" -> Case.DAT
        "i", "ı", "u", "ü", "yi", "yı", "yu", "yü" -> Case.ACC
        "in", "ın", "un", "ün", "nin", "nın", "nun", "nün" -> Case.GEN
        "da", "de", "ta", "te" -> Case.LOC
        "dan", "den", "tan", "ten" -> Case.ABL
        "la", "le", "yla", "yle" -> Case.INS
        else -> null
    }

    private class Sound(val vowel: Char, val endsVowel: Boolean, val hard: Boolean)

    /** İsmin son sözcüğünün okunuşundan: son ünlü, ünlüyle bitiyor mu, sert ünsüzle bitiyor mu. */
    private fun sound(name: String): Sound? {
        val word = name.trim().split(Regex("[\\s\\-]+")).lastOrNull { it.isNotEmpty() } ?: return null
        var w = word.lowercase().map { ACCENT[it] ?: it }.joinToString("").filter { it.isLetter() || it.isDigit() }
        if (w.isEmpty() || w.last().isDigit()) return null          // Aleph-1 gibi: sayı okunuşuna karışma
        val override = SOUND[w]
        if (override != null) {
            w = override
        } else {
            if (w.length >= 4 && w.endsWith("e") && w[w.length - 2] !in VOWELS && w[w.length - 2] != 'y' &&
                w[w.length - 3] in VOWELS
            ) {
                w = w.dropLast(1)                                    // sessiz e: Encore, Dreadmane, Gale
            }
            if (w.length >= 4 && w.endsWith("er")) w = w.dropLast(2) + "ır"   // Rover, Thunder: -ır gibi okunur
        }
        val last = w.last()
        if (last == 'y') return Sound('i', true, false)              // Lucy, Lily: sonda i sesi
        val v = w.lastOrNull { it in VOWELS } ?: return null
        return Sound(v, last in VOWELS, last in HARD)
    }

    /** Hâl ekini isme uygun kurar. İsmi çözemezse null. Dönen: Ad'ek */
    fun attach(name: String, case: Case): String? {
        val s = sound(name) ?: return null
        val back = s.vowel in "aıou"
        val round = s.vowel in "ouöü"
        val a = if (back) "a" else "e"
        val i = when {
            back && !round -> "ı"
            !back && !round -> "i"
            back -> "u"
            else -> "ü"
        }
        val buf = if (s.endsVowel) "y" else ""
        val suf = when (case) {
            Case.DAT -> buf + a
            Case.ACC -> buf + i
            Case.GEN -> if (s.endsVowel) "n" + i + "n" else i + "n"
            Case.LOC -> (if (s.hard) "t" else "d") + a
            Case.ABL -> (if (s.hard) "t" else "d") + a + "n"
            Case.INS -> buf + "l" + a
        }
        return "$name'$suf"
    }

    /** name + (varsa) ek: ek tanınırsa isme uygun olanla değiştirilir, değilse olduğu gibi kalır. */
    fun withSuffix(name: String, suffix: String?): String {
        if (suffix.isNullOrEmpty()) return name
        val c = classify(suffix) ?: return name + "'" + suffix
        return attach(name, c) ?: (name + "'" + suffix)
    }
}
