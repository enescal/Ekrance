package com.example.ekrancevir

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Tam ekran, dokunmatik katman: parmakla çevrilecek bir alan çizdirir (birden fazla alan eklenebilir). Boş dokunuş = iptal. */
class AreaSelectView(ctx: Context, private val existing: List<Rect>, private val onDone: (Rect?) -> Unit) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#5EEAD4"); style = Paint.Style.STROKE; strokeWidth = 3f * d
    }
    private val old = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FDE68A"); style = Paint.Style.STROKE; strokeWidth = 2f * d
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 15f * d; textAlign = Paint.Align.CENTER
    }

    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var has = false

    private fun sel() = RectF(min(sx, ex), min(sy, ey), max(sx, ex), max(sy, ey))

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ex = sx; ey = sy; has = false; invalidate() }
            MotionEvent.ACTION_MOVE -> { ex = e.rawX; ey = e.rawY; has = true; invalidate() }
            MotionEvent.ACTION_UP -> {
                ex = e.rawX; ey = e.rawY
                val r = sel()
                if (r.width() < 60 * d || r.height() < 30 * d) onDone(null)
                else onDone(Rect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt()))
            }
            MotionEvent.ACTION_CANCEL -> onDone(null)
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        canvas.save()
        if (has) {
            val r = sel()
            canvas.clipOutRect(r)
            canvas.drawRect(-loc[0].toFloat(), -loc[1].toFloat(), w + 4000f, h + 4000f, dim)
            canvas.restore()
            canvas.drawRect(r, stroke)
        } else {
            canvas.drawRect(-loc[0].toFloat(), -loc[1].toFloat(), w + 4000f, h + 4000f, dim)
            canvas.restore()
        }
        for (r in existing) canvas.drawRect(r, old)            // daha önce seçilen alanlar sarı çerçeveyle görünür
        val cx = loc[0] + width / 2f
        canvas.drawText("Çevrilecek alanı parmağınla çiz", cx, loc[1] + 90f * d, hint)
        canvas.drawText("(sarı çerçeveler mevcut alanlar • boş dokunuş: iptal)", cx, loc[1] + 90f * d + 22f * d, hint)
    }
}
