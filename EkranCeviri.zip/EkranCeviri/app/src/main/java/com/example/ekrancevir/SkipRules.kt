package com.example.ekrancevir

import android.content.Context

/** Çevrilmemesi gereken yazılar (UID, sayılar, süreler, istatistikler...). Kurallar assets/skip_rules.txt içinde. */
class SkipRules(private val rules: List<Regex>) {

    /** raw: OCR bloğunun ham metni. true ise bu blok hiç çevrilmez. */
    fun skip(raw: String): Boolean {
        val t = TextCleaner.clean(raw).trim()
        if (t.isEmpty()) return true
        return rules.any { it.containsMatchIn(t) }
    }

    companion object {
        fun load(ctx: Context): SkipRules {
            val list = ArrayList<Regex>()
            try {
                ctx.assets.open("skip_rules.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                    lines.forEach { line ->
                        val s = line.trim()
                        if (s.isEmpty() || s.startsWith("#")) return@forEach
                        try { list += Regex(s, RegexOption.IGNORE_CASE) } catch (e: Exception) { /* bozuk satırı atla */ }
                    }
                }
            } catch (e: Exception) {
                // dosya yoksa kuralsız devam
            }
            return SkipRules(list)
        }
    }
}
