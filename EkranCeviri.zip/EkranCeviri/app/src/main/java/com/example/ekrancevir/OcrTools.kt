package com.example.ekrancevir

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import com.google.mlkit.vision.text.Text
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** OCR'ın bulduğu bir yazı bloğu (ekran koordinatında). */
data class OcrBlock(val rect: Rect, val text: String)

object OcrTools {

    /** ML Kit sonucunu kendi blok listemize çevirir; büyütülmüş görüntüden geldiyse kutuları geri ölçekler. */
    fun fromMlKit(t: Text, scale: Float): List<OcrBlock> = t.textBlocks.mapNotNull { b ->
        val r = b.boundingBox ?: return@mapNotNull null
        val rr = if (scale == 1f) Rect(r) else Rect(
            (r.left / scale).toInt(), (r.top / scale).toInt(),
            (r.right / scale).toInt(), (r.bottom / scale).toInt()
        )
        OcrBlock(rr, b.text)
    }

    /** Gri tonlama + kontrast artırma + (küçük yazılar için) büyütme. */
    fun enhance(src: Bitmap, scale: Float): Bitmap {
        val w = (src.width * scale).toInt()
        val h = (src.height * scale).toInt()
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = 1.7f
        val t = 128f * (1f - c)
        val cm = ColorMatrix().apply {
            setSaturation(0f)
            postConcat(ColorMatrix(floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )))
        }
        val p = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) }
        Canvas(out).drawBitmap(src, null, Rect(0, 0, w, h), p)
        return out
    }

    private val wordLike = Regex("^[\"'(]?[A-Za-z][A-Za-z'\\-]*[.,!?…:;\"')]*$")

    /** Metin ne kadar "gerçek İngilizce" görünüyor? Yüksek = daha iyi okunmuş. */
    fun quality(raw: String): Double {
        val text = TextCleaner.clean(raw)
        var s = 0.0
        for (tok in text.split(Regex("\\s+")).filter { it.isNotEmpty() }) {
            s += when {
                wordLike.matches(tok) -> if (tok.count { it.isLetter() } >= 2) 3.0 else 0.5
                tok.all { it.isDigit() || it in ",.%+-x:/" } -> 0.5
                else -> -2.0
            }
        }
        s -= text.count { !(it.isLetterOrDigit() || it.isWhitespace() || it in ".,!?:;'\"-()%+…/&") }
        return s
    }

    private fun overlap(a: Rect, b: Rect): Float {
        val i = Rect()
        if (!i.setIntersect(a, b)) return 0f
        val inter = i.width().toLong() * i.height()
        val m = min(a.width().toLong() * a.height(), b.width().toLong() * b.height())
        return if (m <= 0) 0f else inter.toFloat() / m
    }

    /** İki OCR sonucunu birleştirir: aynı yerdeki bloklardan daha iyi okunanı seçilir. */
    fun merge(a: List<OcrBlock>, b: List<OcrBlock>): List<OcrBlock> {
        if (b.isEmpty()) return a
        if (a.isEmpty()) return b
        val state = IntArray(b.size)            // 0 boş, 1 seçildi, 2 elendi
        val out = ArrayList<OcrBlock>()
        for (x in a) {
            val ov = b.indices.filter { overlap(x.rect, b[it].rect) > 0.5f }
            if (ov.isEmpty()) { out += x; continue }
            if (ov.any { state[it] == 1 }) continue                    // daha iyi bir blok zaten kapsıyor
            if (ov.any { state[it] == 2 }) { out += x; continue }
            val qa = quality(x.text)
            val qb = ov.sumOf { quality(b[it].text) }
            if (qb > qa + max(1.0, abs(qa) * 0.15)) {
                ov.forEach { state[it] = 1; out += b[it] }
            } else {
                ov.forEach { state[it] = 2 }
                out += x
            }
        }
        for (i in b.indices) if (state[i] == 0) out += b[i]
        return out
    }
}
