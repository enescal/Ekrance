package com.example.ekrancevir

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var btn: Button

    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", r.resultCode)
                .putExtra("data", data)
            ContextCompat.startForegroundService(this, i)
            status.text = "Hazır. Çevirmek istediğin uygulamaya geç ve TR balonuna dokun."
            moveTaskToBack(true)
        } else {
            status.text = "Ekran yakalama izni verilmedi."
        }
        btn.isEnabled = true
    }

    private val notif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply { text = "Ekran Çeviri"; textSize = 26f })
        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, pad / 2, 0, pad / 2)
            text = "Ekrandaki İngilizce yazıyı okur, Türkçesini aynı yerin üstüne çizer. " +
                "Başlatınca ekranda bir TR balonu çıkar; çevirmek için dokun, silmek için tekrar dokun."
        }
        root.addView(status)
        btn = Button(this).apply { text = "Başlat"; setOnClickListener { start() } }
        root.addView(btn)
        setContentView(root)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "“Diğer uygulamaların üzerinde göster” iznini aç, sonra geri dönüp tekrar bas."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)

        btn.isEnabled = false
        status.text = "Çeviri modeli hazırlanıyor (ilk seferde yaklaşık 30 MB iner)…"
        val tr = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.TURKISH)
                .build()
        )
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                tr.close()
                status.text = "Ekran yakalama izni isteniyor…"
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                capture.launch(mpm.createScreenCaptureIntent())
            }
            .addOnFailureListener {
                tr.close()
                status.text = "Model indirilemedi. İnternete bağlanıp tekrar dene."
                btn.isEnabled = true
            }
    }
}
