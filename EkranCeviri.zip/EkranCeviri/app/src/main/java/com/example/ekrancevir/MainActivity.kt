package com.example.ekrancevir

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.view.Gravity
import kotlin.math.abs
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var btn: Button

    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", r.resultCode)
                .putExtra("data", data)
            ContextCompat.startForegroundService(this, i)
            status.text = "Hazır. Çevirmek istediğin uygulamaya geç ve TR balonuna dokun."
            moveTaskToBack(true)
        } else {
            status.text = "Ekran yakalama izni verilmedi."
        }
        btn.isEnabled = true
    }

    private val notif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun gradient(radiusDp: Int = 0) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#0B1026"), Color.parseColor("#16305A"), Color.parseColor("#0E8A8F"))
    ).apply { cornerRadius = dp(radiusDp).toFloat() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B1026")
        window.navigationBarColor = Color.parseColor("#0E8A8F")

        val pad = dp(24)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, dp(48), pad, pad)
        }

        // Uygulama simgesi (kapak)
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_foreground)
            background = gradient(28)
            elevation = dp(8).toFloat()
        }, LinearLayout.LayoutParams(dp(128), dp(128)))

        root.addView(TextView(this).apply {
            text = "Ekran Çeviri"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(20), 0, dp(4))
        })
        root.addView(TextView(this).apply {
            text = "Oyundaki İngilizce yazıları anında Türkçeye çevir"
            textSize = 15f
            setTextColor(Color.parseColor("#B3FFFFFF"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(24))
        })

        // Bilgi kartı
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#1AFFFFFF"))
                setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            }
        }
        status = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            setLineSpacing(0f, 1.15f)
            text = "Ekrandaki İngilizce yazıyı okur, Türkçesini aynı yerin üstüne çizer.\n\n" +
                "Başlatınca ekranda bir TR balonu çıkar:\n" +
                "• Dokun: çevir (tekrar dokun: sil)\n" +
                "• Uzun bas: alan seç, otomatik çeviri, durdur"
        }
        card.addView(status)
        root.addView(card, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(24) })


        // Çeviri motoru ayarları
        val engCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#1AFFFFFF"))
                setStroke(dp(1), Color.parseColor("#33FFFFFF"))
            }
        }
        engCard.addView(TextView(this).apply {
            text = "Çeviri motoru"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(4))
        })

        fun note(t: String) = TextView(this).apply {
            text = t
            textSize = 12f
            setTextColor(Color.parseColor("#B3FFFFFF"))
            setPadding(0, dp(4), 0, dp(4))
        }
        fun field(hintText: String, value: String, secret: Boolean, onChange: (String) -> Unit) = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or
                (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_URI)
            hint = hintText
            setText(value)
            textSize = 14f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#80FFFFFF"))
            backgroundTintList = ColorStateList.valueOf(Color.parseColor("#5EEAD4"))
            doAfterTextChanged { onChange(it?.toString().orEmpty()) }
        }

        val geminiBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(field("Gemini API anahtarı", Prefs.geminiKey(this@MainActivity), true) { Prefs.setGeminiKey(this@MainActivity, it) })
            addView(field("Model (boşsa gemini-3.1-flash-lite)", Prefs.geminiModel(this@MainActivity), false) { Prefs.setGeminiModel(this@MainActivity, it) })
            addView(note("Ücretsiz anahtar: aistudio.google.com/apikey. Ekrandaki tüm yazı tek seferde, bağlamıyla çevrilir; en iyi sonuç budur."))
        }
        val deeplBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(field("DeepL API anahtarı", Prefs.deeplKey(this@MainActivity), true) { Prefs.setDeeplKey(this@MainActivity, it) })
            addView(note("Ücretsiz anahtar: deepl.com/pro-api (anahtar :fx ile biter)."))
        }
        val ids = intArrayOf(View.generateViewId(), View.generateViewId(), View.generateViewId())
        val labels = arrayOf(
            "Çevrimdışı (ML Kit) — internetsiz, hızlı",
            "Gemini — en iyi kalite (internet + anahtar)",
            "DeepL — iyi kalite (internet + anahtar)"
        )
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        for (i in 0..2) group.addView(RadioButton(this).apply {
            id = ids[i]
            text = labels[i]
            textSize = 14f
            setTextColor(Color.WHITE)
            buttonTintList = ColorStateList.valueOf(Color.parseColor("#5EEAD4"))
        })
        fun refresh(engine: Int) {
            geminiBox.visibility = if (engine == Prefs.ENGINE_GEMINI) View.VISIBLE else View.GONE
            deeplBox.visibility = if (engine == Prefs.ENGINE_DEEPL) View.VISIBLE else View.GONE
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            val e = ids.indexOf(checkedId).coerceAtLeast(0)
            Prefs.setEngine(this, e)
            refresh(e)
        }
        group.check(ids[Prefs.engine(this).coerceIn(0, 2)])
        refresh(Prefs.engine(this).coerceIn(0, 2))

        engCard.addView(group)
        engCard.addView(geminiBox)
        engCard.addView(deeplBox)
        // Otomatik çeviri tarama hızı
        engCard.addView(TextView(this).apply {
            text = "Otomatik çeviri hızı"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(14), 0, dp(4))
        })
        val speedVals = intArrayOf(500, 800, 1500)
        val speedNames = arrayOf("Hızlı", "Normal", "Ekonomik")
        val speedIds = intArrayOf(View.generateViewId(), View.generateViewId(), View.generateViewId())
        val speedGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        for (i in 0..2) speedGroup.addView(RadioButton(this).apply {
            id = speedIds[i]
            text = speedNames[i]
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 0, dp(12), 0)
            buttonTintList = ColorStateList.valueOf(Color.parseColor("#5EEAD4"))
        })
        speedGroup.setOnCheckedChangeListener { _, checkedId ->
            val k = speedIds.indexOf(checkedId).coerceAtLeast(0)
            Prefs.setIntervalMs(this, speedVals[k])
        }
        val cur = Prefs.intervalMs(this)
        speedGroup.check(speedIds[speedVals.indices.minByOrNull { abs(speedVals[it] - cur) } ?: 1])
        engCard.addView(speedGroup)
        engCard.addView(note("Hızlı: yeni diyalogu daha çabuk yakalar ama pili daha çok kullanır."))
        engCard.addView(note("Bulut seçilirse ekrandaki yazılar Google/DeepL'e gönderilir. Anahtar yalnız bu telefonda saklanır. Bulut hata verirse çevrimdışıya geçilir."))
        root.addView(engCard, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(24) })

        // Başlat butonu
        fun pill(c: Int) = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(c) }
        btn = Button(this).apply {
            text = "Başlat"
            textSize = 17f
            setAllCaps(false)
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            background = StateListDrawable().apply {
                addState(intArrayOf(-android.R.attr.state_enabled), pill(Color.parseColor("#66F97316")))
                addState(intArrayOf(), pill(Color.parseColor("#F97316")))
            }
            setOnClickListener { start() }
        }
        root.addView(btn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)))

        root.addView(TextView(this).apply {
            text = "v0.6 • Çevrimdışı model bir kez iner, sonra internetsiz çalışır"
            textSize = 12f
            setTextColor(Color.parseColor("#80FFFFFF"))
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        })

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            background = gradient()
            addView(root)
        })
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "“Diğer uygulamaların üzerinde göster” iznini aç, sonra geri dönüp tekrar bas."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)

        btn.isEnabled = false
        status.text = "Çeviri modeli hazırlanıyor (ilk seferde yaklaşık 30 MB iner)…"
        val tr = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.TURKISH)
                .build()
        )
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                tr.close()
                status.text = "Ekran yakalama izni isteniyor…"
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                capture.launch(mpm.createScreenCaptureIntent())
            }
            .addOnFailureListener {
                tr.close()
                status.text = "Model indirilemedi. İnternete bağlanıp tekrar dene."
                btn.isEnabled = true
            }
    }
}
