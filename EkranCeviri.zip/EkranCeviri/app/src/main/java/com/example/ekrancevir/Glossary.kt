package com.example.ekrancevir

import android.content.Context
import kotlin.math.abs

/**
 * Oyun sözlüğü (assets/glossary.txt).
 *  - protect/restore: karakter, bölge, eşya adları çeviri sırasında yer tutucuyla korunur.
 *  - canonicalize: OCR'ın 1 harf bozduğu isimleri düzeltir (Yin1in -> Yinlin).
 */
class Glossary(entries: List<Pair<String, String>>) {

    private val map = HashMap<String, String>()                 // küçük harf terim -> yazılacak karşılık
    private val singles = ArrayList<Pair<String, String>>()     // (küçük harf, görünen) tek kelimelik uzun terimler
    private val regex: Regex?

    init {
        for ((t, r) in entries) map[norm(t)] = r
        val terms = entries.map { it.first }.distinct().sortedByDescending { it.length }
        for (t in terms) if (!t.contains(' ') && t.length >= 6) singles += t.lowercase() to t
        regex = if (terms.isEmpty()) null else Regex(
            "(?<![A-Za-z0-9])(" +
                terms.joinToString("|") { t -> t.trim().split(Regex("\\s+")).joinToString("\\s+") { Regex.escape(it) } } +
                ")(?![A-Za-z0-9])",
            RegexOption.IGNORE_CASE
        )
    }

    private fun norm(s: String) = s.trim().lowercase().replace(Regex("\\s+"), " ")

    /** Terimleri QQ0QQ gibi yer tutucuyla değiştirir. Dönen liste: her yer tutucunun gerçek karşılığı. */
    fun protect(text: String): Pair<String, List<String>> {
        val r = regex ?: return text to emptyList()
        val repl = ArrayList<String>()
        val out = r.replace(text) { m ->
            repl += map[norm(m.value)] ?: m.value
            "QQ${repl.size - 1}QQ"
        }
        return out to repl
    }

    /** Yer tutucuları geri koyar. Biri kaybolmuşsa null döner (çağıran korumasız çeviriye düşer). */
    fun restore(translated: String, repl: List<String>): String? {
        val seen = HashSet<Int>()
        val out = PLACEHOLDER.replace(translated) { m ->
            val i = m.groupValues[1].toInt()
            if (i < repl.size) { seen += i; repl[i] } else m.value
        }
        return if (seen.size == repl.size) out else null
    }

    /** Gemini istemine konan, çevrilmeyecek terimlerin listesi. */
    fun termList(): List<String> = map.values.distinct()

    /** Yalnız verilen metinlerde GEÇEN terimler (istem kısa kalır, model dikkatini dağıtmaz). */
    fun termsIn(texts: List<String>): List<String> {
        val r = regex ?: return emptyList()
        val out = LinkedHashSet<String>()
        for (t in texts) for (m in r.findAll(t)) out += map[norm(m.value)] ?: m.value
        return out.toList()
    }

    /** DeepL için: terimleri <x>…</x> içine alır (ignore_tags ile çevrilmez), geri kalanı XML kaçışlar. */
    fun wrapXml(text: String): String {
        fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        val r = regex ?: return esc(text)
        val sb = StringBuilder()
        var last = 0
        for (m in r.findAll(text)) {
            sb.append(esc(text.substring(last, m.range.first)))
            sb.append("<x>").append(esc(map[norm(m.value)] ?: m.value)).append("</x>")
            last = m.range.last + 1
        }
        sb.append(esc(text.substring(last)))
        return sb.toString()
    }

    /** Yer tutucular çıkınca çevrilecek harf kalmadıysa (metin yalnız isimden ibaret) true. */
    fun onlyTerms(protectedText: String): Boolean =
        PLACEHOLDER.replace(protectedText, "").none { it.isLetter() }

    /** OCR yüzünden 1 harf bozulmuş isimleri sözlükteki hâline çevirir. */
    fun canonicalize(text: String): String {
        if (singles.isEmpty()) return text
        return TOKEN.replace(text) { m ->
            val tok = m.value
            if (tok.all { it.isDigit() }) return@replace tok
            if (!(tok[0].isUpperCase() || tok.any { it.isDigit() })) return@replace tok  // isimler büyük harfle başlar
            val low = tok.lowercase()
            if (map.containsKey(low)) return@replace tok
            val hasDigit = tok.any { it.isDigit() }
            // 6 harfli terimler (Encore~Encode gibi yanlış eşleşme riski) yalnız rakam karışmışsa düzeltilir
            singles.firstOrNull { (t, _) ->
                (t.length >= 7 || hasDigit) && abs(t.length - low.length) <= 1 && edit(t, low) <= 1
            }?.second ?: tok
        }
    }

    private fun edit(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }

    companion object {
        private val PLACEHOLDER = Regex("QQ\\s*(\\d+)\\s*QQ", RegexOption.IGNORE_CASE)
        private val TOKEN = Regex("[A-Za-z0-9]{6,}")

        /** Satır biçimi:  İngilizce terim | isteğe bağlı Türkçe karşılık   (# ile yorum). */
        fun load(ctx: Context): Glossary {
            val entries = ArrayList<Pair<String, String>>()
            try {
                ctx.assets.open("glossary.txt").bufferedReader(Charsets.UTF_8).useLines { lines ->
                    lines.forEach { line ->
                        val s = line.trim()
                        if (s.isEmpty() || s.startsWith("#")) return@forEach
                        val parts = s.split("|", limit = 2)
                        val term = parts[0].trim()
                        val rep = parts.getOrNull(1)?.trim().orEmpty()
                        if (term.isNotEmpty()) entries += term to rep.ifEmpty { term }
                    }
                }
            } catch (e: Exception) {
                // sözlük yoksa sessizce sözlüksüz devam
            }
            return Glossary(entries)
        }
    }
}
