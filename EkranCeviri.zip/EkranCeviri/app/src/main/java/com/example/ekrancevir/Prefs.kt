package com.example.ekrancevir

import android.content.Context

/** Ayarlar (SharedPreferences). Anahtarlar yalnız bu uygulamanın özel alanında saklanır. */
object Prefs {
    const val ENGINE_MLKIT = 0
    const val ENGINE_GEMINI = 1
    const val ENGINE_DEEPL = 2

    private fun sp(c: Context) = c.getSharedPreferences("ekran_ceviri", Context.MODE_PRIVATE)

    fun engine(c: Context) = sp(c).getInt("engine", ENGINE_MLKIT)
    fun setEngine(c: Context, v: Int) = sp(c).edit().putInt("engine", v).apply()

    fun geminiKey(c: Context) = sp(c).getString("gemini_key", "").orEmpty().trim()
    fun setGeminiKey(c: Context, v: String) = sp(c).edit().putString("gemini_key", v.trim()).apply()

    fun geminiModel(c: Context) = sp(c).getString("gemini_model", "gemini-3.1-flash-lite").orEmpty().trim()
        .ifEmpty { "gemini-3.1-flash-lite" }
    fun setGeminiModel(c: Context, v: String) = sp(c).edit().putString("gemini_model", v.trim()).apply()

    fun deeplKey(c: Context) = sp(c).getString("deepl_key", "").orEmpty().trim()
    fun setDeeplKey(c: Context, v: String) = sp(c).edit().putString("deepl_key", v.trim()).apply()

    /** Otomatik çeviride ekranın kaç ms'de bir kontrol edileceği. */
    fun intervalMs(c: Context) = sp(c).getInt("interval", 800).coerceIn(400, 5000)
    fun setIntervalMs(c: Context, v: Int) = sp(c).edit().putInt("interval", v).apply()
}
